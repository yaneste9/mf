/// <reference types="react" />

declare module "appOne/Box" {
  const Box: React.ComponentType;

  export default Box;
}
