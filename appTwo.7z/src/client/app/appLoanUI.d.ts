/// <reference types="react" />

declare module "appOne/LoanUI" {
  const LoanUI: React.ComponentType;

  export default LoanUI;
}
