import * as React from "react";

const RemoteButton = React.lazy(() => import("appLoanUI/LoanUI"));

const App = () => (
  <div>
    <h1>Typescript</h1>
    <h2>AppTwo Import MF</h2>
    <React.Suspense fallback="Loading Button">
      <RemoteButton test="This is test" />
    </React.Suspense>
  </div>
);

export default App;
