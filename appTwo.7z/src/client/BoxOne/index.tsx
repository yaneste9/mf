import React from 'react';

const App: React.FC = () => (
  <div>
    <div>BoxOne</div>
  </div>
);

export default App;
