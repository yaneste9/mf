/* eslint-disable @typescript-eslint/no-explicit-any */
declare module '*.css' {
  const content: any;
  export = content;
}
