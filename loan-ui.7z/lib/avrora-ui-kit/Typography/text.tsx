import React from 'react';

import {
  IProps,
  HL1Style,
  HL2Style,
  H1Style,
  H2Style,
  H3Style,
  H4Style,
  H5Style,
  H6Style,
  Subtitle18Style,
  Subtitle15Style,
  Subtitle13Style,
  BodyLong15Style,
  BodySmall15Style,
  BodyLong13Style,
  BodySmall13Style,
  Caption11Style,
} from './text-style';

export const HL1 = (props: IProps) => (
  <HL1Style {...props}>{props.children}</HL1Style>
);
export const HL2 = (props: IProps) => (
  <HL2Style {...props}>{props.children}</HL2Style>
);
export const H1 = (props: IProps) => (
  <H1Style {...props}>{props.children}</H1Style>
);
export const H2 = (props: IProps) => (
  <H2Style {...props}>{props.children}</H2Style>
);
export const H3 = (props: IProps) => (
  <H3Style {...props}>{props.children}</H3Style>
);
export const H4 = (props: IProps) => (
  <H4Style {...props}>{props.children}</H4Style>
);
export const H5 = (props: IProps) => (
  <H5Style {...props}>{props.children}</H5Style>
);
export const H6 = (props: IProps) => (
  <H6Style {...props}>{props.children}</H6Style>
);
export const Subtitle18 = (props: IProps) => (
  <Subtitle18Style {...props}>{props.children}</Subtitle18Style>
);
export const Subtitle15 = (props: IProps) => (
  <Subtitle15Style {...props}>{props.children}</Subtitle15Style>
);
export const Subtitle13 = (props: IProps) => (
  <Subtitle13Style {...props}>{props.children}</Subtitle13Style>
);
export const BodyLong15 = (props: IProps) => (
  <BodyLong15Style {...props}>{props.children}</BodyLong15Style>
);
export const BodySmall15 = (props: IProps) => (
  <BodySmall15Style {...props}>{props.children}</BodySmall15Style>
);
export const BodyLong13 = (props: IProps) => (
  <BodyLong13Style {...props}>{props.children}</BodyLong13Style>
);
export const BodySmall13 = (props: IProps) => (
  <BodySmall13Style {...props}>{props.children}</BodySmall13Style>
);
export const Caption11 = (props: IProps) => (
  <Caption11Style {...props}>{props.children}</Caption11Style>
);
