import styled, { css } from 'styled-components';

import {
  DefaultTheme,
  ITheme,
  ILineHeight,
  IFontSize,
  IFontWeight,
} from '../palette/variables';

export interface IProps {
  children: any;
  color?: string;
  lineHeight?: ILineHeight;
  fontSize?: IFontSize;
  fontWeight?: IFontWeight;
  [propName: string]: any;
  onClick?: () => void;
}

interface IThemeStyle extends Partial<IProps> {
  theme: ITheme;
}

const getCommonParameters = (theme: ITheme, color?: string) => css<
  IThemeStyle
>`
  font-family: ${theme.typography.fontFamily};
  color: ${color || theme.colorList.text.primary};
`;

export const HL1Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[56]};
    line-height: ${theme.typography.lineHeight[60]};
    font-weight: ${theme.typography.fontWeight.bold};
    ${getCommonParameters(theme, color)}
  `}
`;

HL1Style.defaultProps = {
  theme: DefaultTheme,
};

export const HL2Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[48]};
    line-height: ${theme.typography.lineHeight[52]};
    font-weight: ${theme.typography.fontWeight.bold};
    ${getCommonParameters(theme, color)}
  `}
`;

HL2Style.defaultProps = {
  theme: DefaultTheme,
};

export const H1Style = styled.h1<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[40]};
    line-height: ${theme.typography.lineHeight[44]};
    font-weight: ${theme.typography.fontWeight.bold};
    ${getCommonParameters(theme, color)}
  `}
`;

H1Style.defaultProps = {
  theme: DefaultTheme,
};

export const H2Style = styled.h2<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[34]};
    line-height: ${theme.typography.lineHeight[36]};
    font-weight: ${theme.typography.fontWeight.bold};
    ${getCommonParameters(theme, color)}
  `}
`;

H2Style.defaultProps = {
  theme: DefaultTheme,
};

export const H3Style = styled.h3<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[28]};
    line-height: ${theme.typography.lineHeight[32]};
    font-weight: ${theme.typography.fontWeight.semibold};
    ${getCommonParameters(theme, color)}
  `}
`;

H3Style.defaultProps = {
  theme: DefaultTheme,
};

export const H4Style = styled.h4<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[24]};
    line-height: ${theme.typography.lineHeight[28]};
    font-weight: ${theme.typography.fontWeight.semibold};
    ${getCommonParameters(theme, color)}
  `}
`;

H4Style.defaultProps = {
  theme: DefaultTheme,
};

export const H5Style = styled.h5<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[20]};
    line-height: ${theme.typography.lineHeight[24]};
    font-weight: ${theme.typography.fontWeight.semibold};
    ${getCommonParameters(theme, color)}
  `}
`;

H5Style.defaultProps = {
  theme: DefaultTheme,
};

export const H6Style = styled.h6<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[18]};
    line-height: ${theme.typography.lineHeight[24]};
    font-weight: ${theme.typography.fontWeight.semibold};
    ${getCommonParameters(theme, color)}
  `}
`;

H6Style.defaultProps = {
  theme: DefaultTheme,
};

export const Subtitle18Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[18]};
    line-height: ${theme.typography.lineHeight[28]};
    font-weight: ${theme.typography.fontWeight.normal};
    ${getCommonParameters(theme, color)}
  `}
`;

Subtitle18Style.defaultProps = {
  theme: DefaultTheme,
};

export const Subtitle15Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[15]};
    line-height: ${theme.typography.lineHeight[20]};
    font-weight: ${theme.typography.fontWeight.semibold};
    ${getCommonParameters(theme, color)}
  `}
`;

Subtitle15Style.defaultProps = {
  theme: DefaultTheme,
};

export const Subtitle13Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[13]};
    line-height: ${theme.typography.lineHeight[20]};
    font-weight: ${theme.typography.fontWeight.semibold};
    ${getCommonParameters(theme, color)}
  `}
`;

Subtitle13Style.defaultProps = {
  theme: DefaultTheme,
};

export const BodyLong15Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[15]};
    line-height: ${theme.typography.lineHeight[24]};
    font-weight: ${theme.typography.fontWeight.normal};
    ${getCommonParameters(theme, color)}
  `}
`;

BodyLong15Style.defaultProps = {
  theme: DefaultTheme,
};

export const BodySmall15Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[15]};
    line-height: ${theme.typography.lineHeight[20]};
    font-weight: ${theme.typography.fontWeight.normal};
    ${getCommonParameters(theme, color)}
  `}
`;

BodySmall15Style.defaultProps = {
  theme: DefaultTheme,
};

export const BodyLong13Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[13]};
    line-height: ${theme.typography.lineHeight[20]};
    font-weight: ${theme.typography.fontWeight.normal};
    ${getCommonParameters(theme, color)}
  `}
`;

BodyLong13Style.defaultProps = {
  theme: DefaultTheme,
};

export const BodySmall13Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[13]};
    line-height: ${theme.typography.lineHeight[16]};
    font-weight: ${theme.typography.fontWeight.normal};
    ${getCommonParameters(theme, color)}
  `}
`;

BodySmall13Style.defaultProps = {
  theme: DefaultTheme,
};

export const Caption11Style = styled.div<IThemeStyle>`
  ${({ theme, color }: IThemeStyle) => css`
    font-size: ${theme.typography.fontSize[11]};
    line-height: ${theme.typography.lineHeight[16]};
    font-weight: ${theme.typography.fontWeight.normal};
    ${getCommonParameters(theme, color)}
  `}
`;

Caption11Style.defaultProps = {
  theme: DefaultTheme,
};

export const StyledText = styled.div<IThemeStyle>`
  ${({ theme, color, size, lineHeight }: IThemeStyle) => css`
    font-size: ${size ? `${size}px` : theme.typography.fontSize[15]};
    line-height: ${lineHeight
      ? `${lineHeight}px`
      : theme.typography.lineHeight[20]};
    ${getCommonParameters(theme, color)}
  `}
`;

StyledText.defaultProps = {
  theme: DefaultTheme,
};
