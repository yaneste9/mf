declare var __DEV__: boolean;
declare var __localeId__: string;
declare var __localeData__: any;

declare module '*.json';
declare module '@emotion/memoize';

declare module 'scrollmagic';
declare module 'gsap/all';
declare module 'simplebar-react';

declare type FirstArgument<T> = T extends (
  arg1: infer U,
  ...args: any[]
) => any
  ? U
  : any;

interface IAnyValues {
  [propName: string]: any;
}
