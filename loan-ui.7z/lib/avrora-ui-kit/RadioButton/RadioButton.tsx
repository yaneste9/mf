import React from 'react';

import { KEY_CODES } from '../common';

import {
  RadioButtonComponent,
  Radio,
  Input,
  Mark,
  Label,
} from './style';

export interface IProps {
  checked?: boolean;
  dimension?: 'small' | 'big';
  name?: string;
  disabled?: boolean;
  isError?: boolean;
  label: string;
  value: string;
  onChange?: (event: React.ChangeEvent<any>, value: string) => void;
  className?: string;
}

const RadioButton = (props: IProps) => {
  const handleChange = (event: React.ChangeEvent<any>) => {
    const { value, onChange, disabled } = props;
    if (!disabled) {
      onChange && onChange(event, value);
    }
  };

  const handlePressEnter = (event: any) => {
    const { value, onChange, disabled } = props;
    if (
      (!disabled && event.keyCode === KEY_CODES.ENTER) ||
      event.keyCode === KEY_CODES.SPACEBAR
    ) {
      onChange && onChange(event, value);
    }
  };

  const {
    label,
    name,
    value,
    checked,
    disabled,
    isError,
    dimension,
    className,
  } = props;
  return (
    <RadioButtonComponent
      disabled={disabled}
      onKeyUp={handlePressEnter}
      onClick={handleChange}
      className={className}
    >
      <Radio dimension={dimension} tabIndex={1} disabled={disabled}>
        <Input
          tabIndex={-1}
          type="radio"
          checked={checked}
          name={name}
          value={value}
          readOnly={true}
          disabled={disabled}
        />
        <Mark
          dimension={dimension}
          tabIndex={-1}
          disabled={disabled}
          isError={!checked && isError}
        />
      </Radio>
      <Label tabIndex={-1} disabled={disabled} dimension={dimension}>
        {label}
      </Label>
    </RadioButtonComponent>
  );
};

export default RadioButton;
