import React from 'react';

import { RadioGroupContext } from './RadioGroup';
import RadioButton from './RadioButton';

export interface IProps {
  dimension?: 'small' | 'big';
  // name?: string; // не уверена, что правильно это передавать, name назначается сразу группе
  disabled?: boolean;
  isError?: boolean;
  label: string;
  value: string;
  className?: string;
}

const RadioGroupOption = (props: IProps) => {
  const {
    label,
    value,
    disabled,
    isError,
    dimension,
    className,
  } = props;
  return (
    <RadioGroupContext.Consumer>
      {({
        value: groupValue,
        onClick,
        dimension: groupDimendion,
        name,
      }: any) => (
        <RadioButton
          dimension={dimension || groupDimendion}
          checked={value === groupValue} // groupValue - это value выбранной кнопки
          name={name}
          disabled={disabled}
          isError={!(value === groupValue) && isError}
          label={label}
          value={value}
          onChange={() => {
            onClick(value);
          }}
          className={className}
        />
      )}
    </RadioGroupContext.Consumer>
  );
};

export default RadioGroupOption;
