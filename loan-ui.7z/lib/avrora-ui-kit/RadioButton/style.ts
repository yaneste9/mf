import styled from 'styled-components';
import { size } from 'polished';

import { DefaultTheme, ITheme } from '../palette/variables';

import { IProps } from './RadioButton';

interface IRadioBtn extends Partial<IProps> {
  theme: ITheme;
}

export const Mark = styled.div<IRadioBtn>`
  position: absolute;
  ${({ dimension }) =>
    dimension === 'small'
      ? size('18px', '18px')
      : size('22px', '22px')};
  border-radius: 50%;
  ${({ theme, disabled, isError }: IRadioBtn) => `
    border: solid 1px ${
      !disabled ? theme.colors.grey[50] : theme.colors.grey[30]
    };
    ${isError && `border: solid 1px ${theme.colors.red[60]};`}
  `}

  &:focus {
    outline: none;
  }

  &:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%) scale(0);
    transition: transform 0.12s cubic-bezier(0.4, 0, 0.6, 1) 0ms;
    ${({ dimension }) =>
      dimension === 'small'
        ? size('8px', '8px')
        : size('10px', '10px')};
    border-radius: 50%;
    background: ${({ theme, disabled }: IRadioBtn) =>
      !disabled ? theme.colors.blue[60] : theme.colors.grey[30]};
  }
`;

Mark.defaultProps = {
  theme: DefaultTheme,
};

export const Radio = styled.div<IRadioBtn>`
  position: relative;
  ${({ dimension }) =>
    dimension === 'small'
      ? size('26px', '26px')
      : size('30px', '30px')};
  padding: 4px;

  &:before {
    content: '';
    position: absolute;
    border: solid 2px transparent;
    border-radius: 50%;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    transition: border 0.12s cubic-bezier(0, 0, 0.2) 0ms;
  }

  &:focus {
    outline: none;
    & > ${Mark} {
      border-color: ${({ theme, disabled }: IRadioBtn) =>
        disabled ? theme.colors.grey[30] : theme.colors.blue[60]};
    }
    &:before {
      border: solid 2px ${({ theme }) => theme.colors.blue[60]};
    }
  }
`;

Radio.defaultProps = {
  theme: DefaultTheme,
};

export const Input = styled.input<IRadioBtn>`
  position: absolute;
  opacity: 0;
  ${size('1px', '1px')};
  cursor: pointer;

  &:focus {
    outline: none;
  }

  &:checked ~ ${Mark} {
    ${({ theme, disabled }: IRadioBtn) => `
      border: solid 1px ${
        !disabled ? theme.colors.blue[60] : theme.colors.grey[30]
      };
    `}

    &:hover {
      ${({ theme, disabled }: IRadioBtn) =>
        !disabled ? theme.colors.blue[60] : theme.colors.grey[30]};
    }

    &:after {
      transform: translate(-50%, -50%) scale(1);
      transition: transform 0.12s cubic-bezier(0, 0, 0.2, 1) 0ms;
    }
  }
`;

Input.defaultProps = {
  theme: DefaultTheme,
};

export const Label = styled.span<IRadioBtn>`
  display: flex;
  align-items: center;
  margin-left: 5px;
  user-select: none;

  font-family: 'Inter';
  font-weight: normal;
  ${({ dimension, disabled, theme }: IRadioBtn) => `
    font-size: ${dimension === 'small' ? 13 : 15}px;
    line-height: ${dimension === 'small' ? 16 : 20}px;
    cursor: ${!disabled ? 'pointer' : 'default'};
    color: ${
      disabled ? theme.colors.grey[30] : theme.colors.grey[90]
    };
  `}

  &:focus {
    outline: none;
  }
`;

export const RadioButtonComponent = styled.div<IRadioBtn>`
  display: flex;

  &:hover {
    ${Input}:checked ~ ${Mark} {
      border-color: ${({ theme, disabled }: IRadioBtn) =>
        !disabled ? theme.colors.blue[60] : theme.colors.grey[30]};
    }

    ${Mark} {
      border-color: ${({ theme, disabled }: IRadioBtn) =>
        !disabled ? theme.colors.blue[60] : theme.colors.grey[30]};
    }
  }
`;
// scale 0.5
// transition: transform .12s cubic-bezier(0,0,.2,1) 0ms,border-color .12s cubic-bezier(0,0,.2,1) 0ms;

// scale 0
// transition: transform .12s cubic-bezier(.4,0,.6,1) 0ms,border-color .12s cubic-bezier(.4,0,.6,1) 0ms,
