import React, { Component, createContext } from 'react';

export const RadioGroupContext = createContext({});

export interface IProps {
  id: string;
  name: string; // need for group
  dimension?: 'small' | 'medium';
  value: null | string;
  isFocused?: boolean;
  onFocus?: (value?: any) => void;
  onBlur?: (value?: any) => void;
  onClick?: (value: { id: string; value: any }) => void;
}

export interface IState {
  id: string;
  dimension?: 'small' | 'medium';
  value: null | string;
  isFocused: boolean;
  onFocus?: (value?: any) => void;
  onBlur?: (value?: any) => void;
  onClick?: (e: any, value: any) => void;
}

// make stateless component
class RadioGroup extends Component<IProps, IState> {
  static defaultProps = {
    value: null,
    onFocus: () => null,
    onBlur: () => null,
    onChange: () => null,
  };

  state: IState = {
    id: '',
    value: null,
    isFocused: false,
  };

  constructor(props: IProps) {
    super(props);

    this.state = {
      dimension: this.props.dimension,
      id: this.props.id,
      value: this.props.value,
      isFocused: false,
      onFocus: this.handleFocus,
      onBlur: this.handleBlur,
      onClick: this.handleClick,
    };
  }

  static getDerivedStateFromProps(props: IProps, state: IState) {
    const { value } = props;
    if (value && value !== state.value) {
      return { value };
    }
    return null;
  }

  handleFocus = () => {
    const { onFocus, id } = this.props;
    this.setState({ isFocused: true });
    onFocus && onFocus({ id, value: this.state.value });
  };

  handleBlur = () => {
    const { onBlur, id } = this.props;
    this.setState({ isFocused: false });
    onBlur && onBlur({ id, value: this.state.value });
  };

  handleClick = (value: any) => {
    const { onClick, id } = this.props;
    const stateValue = this.state.value;
    this.setState({ value });
    if (value !== stateValue) {
      onClick && onClick({ id, value });
    }
  };

  render() {
    return (
      <RadioGroupContext.Provider value={{ ...this.state }}>
        {this.props.children}
      </RadioGroupContext.Provider>
    );
  }
}

export default RadioGroup;
