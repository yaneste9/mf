interface IKeyCodes {
  [key: string]: number;
}

export const KEY_CODES: IKeyCodes = {
  ALT: 18,
  BACKSPACE: 8,
  CTRL: 17,
  DELETE: 46,
  DOWN: 40,
  ENTER: 13,
  ESCAPE: 27,
  LEFT: 37,
  RIGHT: 39,
  SHIFT: 16,
  SPACEBAR: 32,
  TAB: 9,
  UP: 38,
};
