import { IShape } from '../palette/shape';
import { ITypography } from '../palette/typography';
import { IShadows } from '../palette/variables';
import { IColors } from '../palette/colors';

export interface IButtonProps {
  id?: string;
  view?: 'rounded';
  children: any;
  style?: any;
  color?: 'primary' | 'alternative' | 'secondary';
  dimension?: 'small' | 'medium';
  type?: 'button' | 'reset' | 'submit';
  width?: string;
  isWithIcon?: boolean;
  isWithoutPadding?: boolean;
  isFullWidth?: boolean;
  onClick?: (event: any, id?: string) => void;
  disabled?: boolean;
  className?: string;
  fontFamily?: string;
}

export interface IButton extends Partial<IButtonProps> {
  theme: IThemeProps;
}

export interface IThemeProps {
  shape: IShape;
  borderWidth: string;
  typography: ITypography;
  shadows: IShadows;
  colors: IColors;
}
