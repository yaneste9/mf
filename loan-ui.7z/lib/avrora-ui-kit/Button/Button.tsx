import React from 'react';

import { ButtonComponent, ButtonContent } from './style';
import { IButtonProps } from './interfaces';

const Button = (props: IButtonProps) => {
  const {
    id,
    children,
    onClick,
    disabled,
    color,
    type,
    dimension,
    isFullWidth,
    isWithIcon,
    isWithoutPadding,
    width,
    view,
    className,
    fontFamily,
  } = props;

  const handleOnClick = (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>,
  ) => {
    onClick && onClick(event, id);
  };

  const handlePressEnter = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      onClick && onClick(event);
    }
  };

  return (
    <ButtonComponent
      data-element="button-component"
      id={id}
      view={view}
      onClick={!disabled ? handleOnClick : () => ({})}
      onKeyUp={!disabled ? handlePressEnter : () => ({})}
      color={color}
      type={type}
      dimension={dimension}
      isWithIcon={isWithIcon}
      isFullWidth={isFullWidth}
      width={width}
      disabled={disabled}
      className={className}
    >
      <ButtonContent
        data-element="button-content"
        view={view}
        tabIndex={-1}
        isWithIcon={isWithIcon}
        isWithoutPadding={isWithoutPadding}
        isFullWidth={isFullWidth}
        dimension={dimension}
        fontFamily={fontFamily}
      >
        {children}
      </ButtonContent>
    </ButtonComponent>
  );
};

Button.defaultProps = {
  dimension: 'medium',
  type: 'button',
  color: 'primary',
};

export default Button;
