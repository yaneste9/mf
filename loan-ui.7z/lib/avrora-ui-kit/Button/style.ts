import styled, { css } from 'styled-components';
import { rgba } from 'polished';

import { BorderRadius } from '../palette/style-utils';
import { INNERSHADOWS, DefaultTheme } from '../palette/variables';
import { FONTS } from '../palette/fonts';

import { IThemeProps, IButton } from './interfaces';

const isMobile: boolean = false;

const small = (theme: IThemeProps, isWithIcon?: boolean) => css`
  font-size: ${theme.typography.fontSize2};
  line-height: ${theme.typography.lineHeight2};
  padding: ${isWithIcon ? '4px' : '4px 16px'};

  > *:not(:first-child) {
    margin-left: 8px;
  }
`;

const medium = (theme: IThemeProps, isWithIcon?: boolean) => css`
  font-size: ${theme.typography.fontSize1};
  line-height: ${theme.typography.lineHeight2};
  padding: ${isWithIcon ? '8px' : '8px 24px'};

  > *:not(:first-child) {
    margin-left: 12px;
  }
`;

const isWithIconStyle = (theme: IThemeProps, color: string) => css`
  div {
    cursor: pointer;
  }
`;

const disabledStyle = (
  theme: IThemeProps,
  isWithIcon?: boolean,
  color?: 'primary' | 'alternative' | 'secondary',
) => {
  switch (color) {
    case 'alternative':
      return css`
        cursor: default;
        pointer-events: none;
        color: ${theme.colors.grey[100]};
        background-color: ${theme.colors.grey.white};
        box-shadow: none;
        border: solid ${theme.borderWidth} ${theme.colors.grey[100]};

        ${isWithIcon && isWithIconStyle(theme, 'gray')};
      `;
    case 'secondary':
      return css`
        cursor: default;
        pointer-events: none;
        color: ${theme.colors.grey[80]};
        background-color: transparent;
        box-shadow: none;
        border-bottom: 2px dotted ${theme.colors.grey[80]};

        ${isWithIcon && isWithIconStyle(theme, 'gray')};
      `;
    default:
      return css`
        cursor: default;
        pointer-events: none;
        color: ${theme.colors.grey.white};
        background-color: ${theme.colors.grey[50]};
        box-shadow: none;
        border: solid ${theme.borderWidth} transparent;

        ${isWithIcon && isWithIconStyle(theme, 'greyMouse')};
      `;
  }
};

const focusStyle = (theme: IThemeProps, color: string) => css`
  &::-moz-focus-inner {
    border: 0;
  }
  &:focus {
    outline: none;
  }
`;

const dimensionButton = {
  small,
  medium,
};

const primary = (theme: IThemeProps, isWithIcon?: boolean) => css`
  border-radius: 4px;
  letter-spacing: 0.15em;
  background-color: ${theme.colors.blue[80]};
  border: solid ${theme.borderWidth} ${theme.colors.blue[80]};
  color: ${theme.colors.grey.white};
  box-shadow: 0px 4px 8px ${theme.colors.purple[100]};

  ${!isMobile &&
  `
    &:hover {
      background-color: ${theme.colors.blue[70]};
      border: solid ${theme.borderWidth} ${theme.colors.blue[70]};
      box-shadow: 0px 4px 8px ${theme.colors.blue[30]};
    }`}

  &:active {
    background-color: ${theme.colors.blue[100]};
    border: solid ${theme.borderWidth} ${theme.colors.blue[100]};
    box-shadow: none;
  }

  ${focusStyle(theme, 'white')}
  ${isWithIcon && isWithIconStyle(theme, 'white')};
`;

const alternative = (theme: IThemeProps, isWithIcon?: boolean) => css`
  border-radius: 4px;
  letter-spacing: 0.15em;
  background-color: ${theme.colors.grey.white};
  border: solid ${theme.borderWidth} ${theme.colors.blue[80]};
  color: ${theme.colors.blue[80]};

  ${!isMobile &&
  `
    &:hover {
      background-color: ${theme.colors.grey.white};
      border: solid ${theme.borderWidth} ${theme.colors.blue};
    }`}

  &:active {
    background-color: ${theme.colors.grey[50]};
    border: solid ${theme.borderWidth} ${theme.colors.blue[80]};
  }

  ${focusStyle(theme, 'white')}
  ${isWithIcon && isWithIconStyle(theme, 'white')};
`;

const secondary = (theme: IThemeProps, isWithIcon?: boolean) => css`
  background-color: transparent;
  border: none;
  border-bottom: 2px dotted ${theme.colors.blue[80]};
  color: ${theme.colors.blue[80]};
  padding: 2px 0px;

  ${!isMobile &&
  `
    &:hover {
      background-color: transparent;
      border: none;
      color: ${theme.colors.blue[70]};
      border-bottom: 2px dotted ${theme.colors.blue[70]};
    }`}

  &:active {
    background-color: transparent;
    border: none;
    color: ${theme.colors.blue[70]};
    border-bottom: 2px dotted ${theme.colors.blue[70]};
  }

  ${focusStyle(theme, 'white')}
  ${isWithIcon && isWithIconStyle(theme, 'white')};
`;

const colorButton = {
  primary,
  alternative,
  secondary,
};

const getWidth = (isFullWidth?: boolean, width?: string) => {
  if (isFullWidth) {
    return '100%';
  }
  return width ? width : 'auto';
};

const getRounded = (theme: IThemeProps, dimension?: string) => {
  switch (dimension) {
    case 'small':
      return theme.shape.borderRadiusSmall;
    default:
      return theme.shape.borderRadiusMedium;
  }
};

export const ButtonComponent = styled.button<IButton>`
  padding: 0;
  ${({ isFullWidth, width, theme }: IButton) => css`
    width: ${getWidth(isFullWidth, width)};
    font-family: ${theme.typography.fontFamily};
    ${BorderRadius.roundBorder(theme.shape.borderRadiusDefault)};
    display: ${isFullWidth ? 'flex' : 'inline-flex'};
  `}
  text-decoration: none;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  ${({ view, dimension, theme }: IButton) =>
    view === 'rounded' &&
    `border-radius: ${getRounded(theme, dimension)}`};
  ${({ color, isWithIcon, theme }: IButton) =>
    color && colorButton[color](theme, isWithIcon)};
  ${({ disabled, isWithIcon, theme, color }: IButton) =>
    disabled ? disabledStyle(theme, isWithIcon, color) : ''};
`;

ButtonComponent.defaultProps = {
  theme: DefaultTheme,
};

export const ButtonContent = styled.span<IButton>`
  font-family: ${({ fontFamily }) =>
    fontFamily ? fontFamily : FONTS.Regular};
  cursor: pointer;
  height: 100%;
  width: 100%;
  display: ${({ isFullWidth }) =>
    isFullWidth ? 'flex' : 'inline-flex'};
  justify-content: center;
  align-items: center;
  border-radius: ${({ dimension, view, theme }: IButton) =>
    view === 'rounded'
      ? getRounded(theme, dimension)
      : theme.shape.borderRadiusDefault};
  ${({ isWithoutPadding }) =>
    isWithoutPadding ? 'padding: 0px !important;' : ''}

  &:focus {
    outline: none;
  }

  ${({ dimension, isWithIcon, theme }: IButton) =>
    dimension && dimensionButton[dimension](theme, isWithIcon)};
`;

ButtonContent.defaultProps = {
  theme: DefaultTheme,
};
