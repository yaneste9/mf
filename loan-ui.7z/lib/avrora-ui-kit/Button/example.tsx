import React from 'react';
// import React, { Fragment } from 'react';
// // import { RefreshIcon } from '@holism/icons';

// // import { PreviewComponent } from '../../SystemComponents/Playground';
// import {
//   Border,
//   Separator,
//   TitleExample,
//   DescExample,
//   Row,
//   GreyDescription,
// } from '../../SystemComponents/Blocks/style';
// import { COLORS } from '../Palette/export';
// import { isMobile } from '../utils';

// import Button from './Button';

// const code = `
// import { Button } from '@holism/core';
// import { RefreshIcon } from '@holism/icons';

// () => (
//   <>
//     {/* Размеры */}
//     <Button dimension="medium">Надпись</Button>

//     {/* Скругление углов */}
//     <Button view="rounded">Надпись</Button>

//     {/* Кнопки с иконкой */}
//     <Button dimension="medium" view="rounded" isWithIcon={true}>
//       <RefreshIcon size={20} />
//       <span>Надпись</span>
//     </Button>
//     <Button dimension="medium" view="rounded" isWithIcon={true}>
//       <RefreshIcon size={20} />
//     </Button>

//     {/* Цвета */}
//     <Button dimension="medium" color="secondary">
//       Надпись
//     </Button>

//     {/* Неактивная кнопка */}
//     <Button disabled={true} color="alert">
//       Alert
//     </Button>
//   </>
// )
// `;

// const interfaces = `
// interface Props = {
//   id?: string;
//   view?: 'rounded';
//   children: any;
//   style?: any;
//   color?: 'primary' | 'secondary' | 'grey' | 'white' | 'red' | 'green';
//   dimension?: 'micro' | 'small' | 'medium' | 'large';
//   type?: 'button' | 'reset' | 'submit';
//   width?: string;
//   isWithIcon?: boolean;
//   isFullWidth?: boolean;
//   onClick?: (event: any, id?: string) => void;
//   disabled?: boolean;
//   className?: string;
// }
// `;

// const preDarkBorder = {
//   marginBottom: '-1px',
//   paddingBottom: '14px',
// };

// const DarkBorder = {
//   paddingTop: '14px',
//   paddingBottom: isMobile ? '8px' : '32px',
//   border: '0px',
// };

// const Preview = () => (
//   <Fragment>
//     <TitleExample>Размеры</TitleExample>
//     <DescExample>
//       Для всех кнопок мы используем 4 размера: Large, Medium, Small и Micro.
//     </DescExample>
//     <Border flex={true}>
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button id="button1">Надпись</Button>
//         <Separator height="12px" width={isMobile ? '100%' : '20px'} />
//         <Button dimension="medium">Надпись</Button>
//         <Separator height="12px" width={isMobile ? '100%' : '20px'} />
//         <Button dimension="small">Надпись</Button>
//         <Separator height="12px" width={isMobile ? '100%' : '20px'} />
//         <Button dimension="micro">Надпись</Button>
//       </Row>
//     </Border>
//     <TitleExample>Скругление углов </TitleExample>
//     <DescExample>
//       Если стандартных кнопок недостаточно, можно использовать кнопки со скругленными краями.
//     </DescExample>
//     <Border flex={true}>
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button view="rounded">Надпись</Button>
//         <Separator height="12px" width={isMobile ? '100%' : '20px'} />
//         <Button dimension="medium" view="rounded">
//           Надпись
//         </Button>
//         <Separator height="12px" width={isMobile ? '100%' : '20px'} />
//         <Button dimension="small" view="rounded">
//           Надпись
//         </Button>
//         <Separator height="12px" width={isMobile ? '100%' : '20px'} />
//         <Button dimension="micro" view="rounded">
//           Надпись
//         </Button>
//       </Row>
//     </Border>
//     <TitleExample>Кнопки с иконкой</TitleExample>
//     <Border flex={true}>
//       {!isMobile && (
//         <>
//           <Row>
//             <Button dimension="medium" isWithIcon={true}>
//               <RefreshIcon size={20} />
//               <span>Надпись</span>
//             </Button>
//             <Separator width="20px" />
//             <Button dimension="medium" isWithIcon={true}>
//               <RefreshIcon size={20} />
//             </Button>
//             <Separator width="20px" />
//             <Button dimension="medium" view="rounded" isWithIcon={true}>
//               <RefreshIcon size={20} />
//               <span>Надпись</span>
//             </Button>
//             <Separator width="20px" />
//             <Button dimension="medium" view="rounded" isWithIcon={true}>
//               <RefreshIcon size={20} />
//             </Button>
//           </Row>
//         </>
//       )}
//       {isMobile && (
//         <>
//           <Separator width="12px" />
//           <Row>
//             <Button dimension="medium" isWithIcon={true}>
//               <RefreshIcon size={20} />
//               <span>Надпись</span>
//             </Button>
//             <Separator width="20px" />
//             <Button dimension="medium" isWithIcon={true}>
//               <RefreshIcon size={20} />
//             </Button>
//           </Row>
//           <Separator height="12px" width="100%" />
//           <Row>
//             <Button dimension="medium" isWithIcon={true} view="rounded">
//               <RefreshIcon size={20} />
//               <span>Надпись</span>
//             </Button>
//             <Separator width="20px" />
//             <Button dimension="medium" isWithIcon={true} view="rounded">
//               <RefreshIcon size={20} />
//             </Button>
//           </Row>
//         </>
//       )}
//     </Border>
//     <TitleExample>Цвета</TitleExample>
//     <DescExample>Для различных случаев предусмотрены разные стили кнопок.</DescExample>
//     <Border style={preDarkBorder}>
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button dimension="medium">Надпись</Button>
//         <Separator width={isMobile ? '100%' : '16px'} height="8px" />
//         <GreyDescription fontSize="14px">Основная кнопка</GreyDescription>
//         <Separator width={isMobile ? '100%' : '0px'} height="8px" />
//       </Row>
//       <Separator height={isMobile ? '16px' : '28px'} />
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button dimension="medium" color="secondary">
//           Надпись
//         </Button>
//         <Separator width={isMobile ? '100%' : '16px'} height="8px" />
//         <GreyDescription fontSize="14px">Второстепенная кнопка</GreyDescription>
//         <Separator width={isMobile ? '100%' : '0px'} height="8px" />
//       </Row>
//       <Separator height={isMobile ? '16px' : '28px'} />
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button dimension="medium" color="grey">
//           Надпись
//         </Button>
//         <Separator width={isMobile ? '100%' : '16px'} height="8px" />
//         <GreyDescription fontSize="14px">Третьестепенная кнопка</GreyDescription>
//         <Separator width={isMobile ? '100%' : '0px'} height="8px" />
//       </Row>
//       <Separator height={isMobile ? '16px' : '28px'} />
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button dimension="medium" color="red">
//           Надпись
//         </Button>
//         <Separator width={isMobile ? '100%' : '16px'} height="8px" />
//         <GreyDescription fontSize="14px">Кнопка для обозначения критичных действий</GreyDescription>
//         <Separator width={isMobile ? '100%' : '0px'} height="8px" />
//       </Row>
//       <Separator height={isMobile ? '16px' : '28px'} />
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button dimension="medium" color="green">
//           Надпись
//         </Button>
//         <Separator width={isMobile ? '100%' : '16px'} height="8px" />
//         <GreyDescription fontSize="14px">
//           Кнопка для обозначения позитивных действий
//         </GreyDescription>
//         <Separator width={isMobile ? '100%' : '0px'} height="8px" />
//       </Row>
//       <Separator height={isMobile ? '16px' : '28px'} />
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button dimension="medium" disabled={true}>
//           Надпись
//         </Button>
//         <Separator width={isMobile ? '100%' : '16px'} height="8px" />
//         <GreyDescription fontSize="14px">Неактивная кнопка</GreyDescription>
//         <Separator width={isMobile ? '100%' : '0px'} height="8px" />
//       </Row>
//     </Border>
//     <Border flex={true} background={COLORS.night} style={DarkBorder}>
//       <Row isWrap={isMobile} alignItems="flex-start">
//         <Button dimension="medium" color="white">
//           Надпись
//         </Button>
//         <Separator width={isMobile ? '100%' : '16px'} height="8px" />
//         <GreyDescription color={COLORS.white} fontSize="14px">
//           Кнопка для темного фона
//         </GreyDescription>
//       </Row>
//     </Border>
//   </Fragment>
// );

const Example = () => (
  <div>
    {/* <PreviewComponent
      previewComponent={<Preview />}
      codeComponent={code}
      interfaceComponent={interfaces}
    /> */}
  </div>
);

export const Info = {
  name: 'Button',
  component: Example,
};
