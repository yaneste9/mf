import { FONTS } from './fonts';
import { ILineHeight, IFontSize, IFontWeight } from './variables.js';

export interface ITypography {
  fontFamily: string;
  fontSize: IFontSize;
  lineHeight: ILineHeight;
  fontWeight: IFontWeight;

  // TODO: refactor and remove it
  fontSize0: string;
  fontSize1: string;
  fontSize2: string;
  fontSize3: string;
  fontSizeH1: string;
  fontSizeH2: string;
  fontSizeH3: string;
  fontSizeH1Promo: string;
  fontSizeH2Promo: string;
  lineHeight1: string;
  lineHeight2: string;
  lineHeight3: string;
  lineHeightH1: string;
  lineHeightH2: string;
  lineHeightH3: string;
  lineHeightH1Promo: string;
  lineHeightH2Promo: string;
}

export const FontSize: IFontSize = {
  11: '11px',
  13: '13px',
  15: '15px',
  18: '18px',
  20: '20px',
  24: '24px',
  28: '28px',
  34: '34px',
  40: '40px',
  48: '48px',
  56: '56px',
};

export const LineHeight: ILineHeight = {
  16: '16px',
  20: '20px',
  24: '24px',
  28: '28px',
  32: '32px',
  36: '36px',
  44: '44px',
  52: '52px',
  60: '60px',
};

export const FontWeight: IFontWeight = {
  100: 100,
  200: 200,
  300: 300,
  500: 500,
  600: 600,
  800: 800,
  900: 900,
  normal: 400,
  semibold: 600,
  bold: 700,
};

export const Typography: ITypography = {
  fontFamily: FONTS.Default,
  fontSize: FontSize,
  lineHeight: LineHeight,
  fontWeight: FontWeight,

  // TODO: refactor and remove it
  fontSize0: '11px',
  fontSize1: '16px',
  fontSize2: '14px',
  fontSize3: '12px',
  fontSizeH1: '28px',
  fontSizeH2: '22px',
  fontSizeH3: '18px',
  fontSizeH1Promo: '48px',
  fontSizeH2Promo: '40px',
  lineHeight1: '24px',
  lineHeight2: '20px',
  lineHeight3: '16px',
  lineHeightH1: '28px',
  lineHeightH2: '24px',
  lineHeightH3: '24px',
  lineHeightH1Promo: '52px',
  lineHeightH2Promo: '40px',
};
