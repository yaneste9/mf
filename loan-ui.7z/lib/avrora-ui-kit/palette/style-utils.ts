import { css, CSSObject } from 'styled-components';

import * as style from './variables';

export const MEDIA = {
  tablet: (p: CSSObject, ...args: TemplateStringsArray[]) => css`
    @media (${style.MEDIA.tablet}) {
      ${css(p, ...args)}
    }
  `,
  desktop1024: (p: CSSObject, ...args: TemplateStringsArray[]) => css`
    @media (${style.MEDIA.desktop1024}) {
      ${css(p, ...args)}
    }
  `,
  desktop: (p: CSSObject, ...args: TemplateStringsArray[]) => css`
    @media (${style.MEDIA.desktop}) {
      ${css(p, ...args)}
    }
  `,
  desktopXl: (p: CSSObject, ...args: TemplateStringsArray[]) => css`
    @media (${style.MEDIA.desktopХl}) {
      ${css(p, ...args)}
    }
  `,
};

export const BorderRadius = {
  roundBorder: (borderRadius: string) => css`
    border-radius: ${borderRadius};
  `,
  roundBorderTop: (borderRadius: string) => css`
    border-radius: ${borderRadius} ${borderRadius} 0 0;
  `,
  roundBorderBottom: (borderRadius: string) => css`
    border-radius: 0 0 ${borderRadius} ${borderRadius};
  `,
};
