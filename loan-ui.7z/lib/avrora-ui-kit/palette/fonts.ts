const DefaultFontName = 'Inter';

export const FONTS = {
  Default: DefaultFontName,
  Bold: `${DefaultFontName} Bold`,
  SemiBold: `${DefaultFontName} Semibold`,
  ExtraBold: `${DefaultFontName} ExtraBold`,
  ExtraLight: `${DefaultFontName} ExtraLight`,
  Light: `${DefaultFontName} Light`,
  Medium: `${DefaultFontName} Medium`,
  Thin: `${DefaultFontName} Thin`,
  Regular: DefaultFontName,
  Black: `${DefaultFontName} Black`,
};
