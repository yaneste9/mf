export interface IBasicColor {
  50: string;
  40: string;
  30: string;
  20: string;
  10: string;
}

export interface IColor extends IBasicColor {
  100: string;
  90: string;
  80: string;
  70: string;
  60: string;
  50: string;
  40: string;
  30: string;
  20: string;
  10: string;
}

interface IColdGreyColor extends IColor {
  5: string;
}

interface IGreyColor extends IColdGreyColor {
  white: string;
}

const BasicBlueColors: IColor = {
  100: '#001144',
  90: '#001D6D',
  80: '#022D9A',
  70: '#0142D3',
  60: '#0062FF',
  50: '#307FFF',
  40: '#6FA3FF',
  30: '#A7C7FF',
  20: '#D6E4FE',
  10: '#EDF5FF',
};

const NeutralBlueColors: IColor = {
  100: '#011A52',
  90: '#002882',
  80: '#003C96',
  70: '#1556BB',
  60: '#2375E1',
  50: '#1B81EE',
  40: '#3DBFFF',
  30: '#92DBFF',
  20: '#CCEEFF',
  10: '#E5F8FF',
};

const GreyColors: IGreyColor = {
  100: '#141414',
  90: '#242424',
  80: '#383838',
  70: '#525252',
  60: '#6C6C6C',
  50: '#7E7E7E',
  40: '#A8A8A8',
  30: '#B9B9B9',
  20: '#D8D8D8',
  10: '#EEEEEE',
  5: '#F5F5F5',
  white: '#FFFFFF',
};

const GreenColors: IColor = {
  100: '#00230C',
  90: '#003111',
  80: '#04451A',
  70: '#096227',
  60: '#128238',
  50: '#1BA049',
  40: '#32C665',
  30: '#66DD8F',
  20: '#A9F1C1',
  10: '#E6FFEF',
};

const RedColors: IColor = {
  100: '#320000',
  90: '#520606',
  80: '#780A0A',
  70: '#A71212',
  60: '#D92020',
  50: '#F64E4E',
  40: '#FF7C7C',
  30: '#FFA7A7',
  20: '#FFD4D4',
  10: '#FFEFEF',
};

const OrangeColors: IColor = {
  100: '#3D1100',
  90: '#591C04',
  80: '#7A2503',
  70: '#A63208',
  60: '#D63F09',
  50: '#FF5C22',
  40: '#FF8D64',
  30: '#FFB799',
  20: '#FFD7C3',
  10: '#FFF1E5',
};

const PurpleColors: IColor = {
  100: '#1C0F30',
  90: '#31135E',
  80: '#491D8B',
  70: '#6929C4',
  60: '#8A3FFC',
  50: '#A56EFF',
  40: '#BE95FF',
  30: '#D4BBFF',
  20: '#E8DAFF',
  10: '#F6F2FF',
};

const ColdGreyColors: IColdGreyColor = {
  100: '#121416',
  90: '#23262F',
  80: '#353843',
  70: '#4F525D',
  60: '#676C77',
  50: '#7E8390',
  40: '#A3A8B2',
  30: '#C0C4CC',
  20: '#DADDE3',
  10: '#EDF0F4',
  5: '#F5F6F8',
};

const YellowColors: IBasicColor = {
  50: '#FFC400',
  40: '#FDD14C',
  30: '#FEE189',
  20: '#FEEEB8',
  10: '#FEF5D7',
};

export interface IColors {
  neutral: IColor;
  blue: IColor;
  grey: IGreyColor;
  green: IColor;
  red: IColor;
  orange: IColor;
  purple: IColor;
  coldGrey: IColdGreyColor;
  yellow: IBasicColor;
}

// TODO [PoltP]: OLD, remove it after discussion
export const COLORS: IColors = {
  neutral: NeutralBlueColors,
  blue: BasicBlueColors,
  grey: GreyColors,
  green: GreenColors,
  red: RedColors,
  orange: OrangeColors,
  purple: PurpleColors,
  coldGrey: ColdGreyColors,
  yellow: YellowColors,
};

const COLORS_UI = {
  base: BasicBlueColors[60],
  secondary: GreyColors[50],
  inverse: GreyColors.white,
};

const COLORS_NEUTRAL_UI = {
  base: NeutralBlueColors[90],
  secondary: GreyColors[50],
  inverse: GreyColors.white,
};

const COLORS_STATUS = {
  notify: BasicBlueColors[60],
  success: GreenColors[50],
  error: RedColors[60],
  warning: OrangeColors[50],
};

const COLORS_TEXT = {
  primary: GreyColors[90],
  secondary: GreyColors[50],
  disabled: GreyColors[30],
  inverse: GreyColors.white,
  link: BasicBlueColors[60],
  error: RedColors[60],
  success: GreenColors[50],
};

const COLORS_BACKGROUND = {
  surface: GreyColors.white,
  backdrop: GreyColors[5],
  backdrop2: ColdGreyColors[5],
  disabled: GreyColors[10],
  inverse: GreyColors[90],
  // undefined: GreyColors[80]
};

const COLORS_INTERACTIVE = {
  default: {
    base: BasicBlueColors[60],
    hover: BasicBlueColors[70],
    pressed: BasicBlueColors[80],
  },
  success: {
    base: GreenColors[50],
    hover: GreenColors[60],
    pressed: GreenColors[70],
  },
  error: {
    base: RedColors[60],
    hover: RedColors[70],
    pressed: RedColors[80],
  },
  tertiary: {
    base: GreyColors[10],
    hover: GreyColors[20],
    pressed: GreyColors[30],
  },
};

const COLORS_INVERSE = {
  base: GreyColors.white,
  link: BasicBlueColors[50],
  text: BasicBlueColors[40],
  warning: OrangeColors[50],
  error: RedColors[50],
  success: GreenColors[40],
  secondary: GreyColors[30],
};

export interface IColorList {
  ui: {
    base: string;
    secondary: string;
    inverse: string;
  };
  status: {
    notify: string;
    success: string;
    error: string;
    warning: string;
  };
  text: {
    primary: string;
    secondary: string;
    disabled: string;
    inverse: string;
    link: string;
    error: string;
    success: string;
  };
  background: {
    surface: string;
    backdrop: string;
    backdrop2: string;
    disabled: string;
    inverse: string;
  };
  interactive: {
    default: {
      base: string;
      hover: string;
      pressed: string;
    };
    success: {
      base: string;
      hover: string;
      pressed: string;
    };
    error: {
      base: string;
      hover: string;
      pressed: string;
    };
    tertiary: {
      base: string;
      hover: string;
      pressed: string;
    };
  };
  inverse: {
    base: string;
    link: string;
    text: string;
    warning: string;
    error: string;
    success: string;
    secondary: string;
  };
}

export const BASIC_COLORS: IColorList = {
  ui: COLORS_UI,
  status: COLORS_STATUS,
  text: COLORS_TEXT,
  background: COLORS_BACKGROUND,
  interactive: COLORS_INTERACTIVE,
  inverse: COLORS_INVERSE,
};

export const NEUTRAL_COLORS: IColorList = {
  ui: COLORS_NEUTRAL_UI,
  status: COLORS_STATUS,
  text: COLORS_TEXT,
  background: COLORS_BACKGROUND,
  interactive: COLORS_INTERACTIVE,
  inverse: COLORS_INVERSE,
};
