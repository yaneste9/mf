import { rgba } from 'polished';

import { Typography, ITypography } from './typography';
import { Shape, IShape } from './shape';
import { COLORS, IColors, IColorList, BASIC_COLORS } from './colors';

export interface IMedia {
  mobile: string;
  tablet: string;
  desktop1024: string;
  desktop: string;
  desktopХl: string;
}

export interface IShadows {
  shadowLarge?: string;
  shadowSmallLight?: string;
  shadowSmallDeep?: string;
}

interface IInnerShadows {
  shadowLarge: string;
  shadowSmall: string;
}

export interface IDimensions {
  maxWidth: string;
  cardWidth: string;
  borderRadius: string;
  gridColWidth: string;
}

export interface ITheme {
  shape: IShape;
  borderWidth: string;
  typography: ITypography;
  shadows: IShadows;
  colors: IColors;
  colorList: IColorList;
}

export interface IFontSize {
  [key: number]: string;
}

export interface ILineHeight {
  [key: number]: string;
}

export interface IFontWeight {
  [key: number]: number;
  normal: number;
  semibold: number;
  bold: number;
}

export const MEDIA: IMedia = {
  mobile: 'max-width: 529px',
  tablet: 'max-width: 949px',
  desktop1024: 'max-width: 1024px',
  desktop: 'max-width: 1250px',
  desktopХl: 'min-width: 1250px',
};

export const SHADOWS: IShadows = {
  shadowLarge: `0 8px 20px 0 ${rgba(COLORS.blue[100], 0.15)}`,
  shadowSmallLight: `0 4px 8px 0 ${rgba(COLORS.blue[100], 0.15)}`,
  shadowSmallDeep: `0 4px 8px 0 ${rgba(COLORS.blue[100], 0.3)}`,
};

export const INNERSHADOWS: IInnerShadows = {
  shadowLarge: '0 0 0 1000px',
  shadowSmall: '0 0 0 1px',
};

export const DIMENSIONS: IDimensions = {
  maxWidth: '1280px',
  cardWidth: '936px',
  borderRadius: '2px',
  gridColWidth: '266px',
};

export const DefaultTheme: ITheme = {
  shape: Shape,
  borderWidth: '2px',
  typography: Typography,
  shadows: SHADOWS,
  colors: COLORS,
  colorList: BASIC_COLORS,
};
