export interface IShape {
  borderRadiusDefault: string;
  borderRadiusCircle: string;
  borderRadiusMicro: string;
  borderRadiusSmall: string;
  borderRadiusMedium: string;
  borderRadiusLarge: string;
}

export const Shape = {
  borderRadiusDefault: '2px',
  borderRadiusCircle: '50%',
  borderRadiusMicro: '16px',
  borderRadiusSmall: '20px',
  borderRadiusMedium: '24px',
  borderRadiusLarge: '28px',
};
