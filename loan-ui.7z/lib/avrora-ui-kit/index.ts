export {
  COLORS,
  BASIC_COLORS,
  NEUTRAL_COLORS,
  SHADOWS,
  DIMENSIONS,
  BorderRadius,
  MEDIA,
  DefaultTheme,
} from './palette/index';
export { default as Button } from './Button/Button';
export { default as Switch } from './Switch/Switch';
export { default as Tabs } from './Tabs/Tabs';
