import MobileDetect from 'mobile-detect';

export const getChar = (e: any) => {
  if (e.which === null) {
    if (e.keyCode < 32) {
      return null;
    }
    return String.fromCharCode(e.keyCode);
  }
  if (e.which !== 0 && e.charCode !== 0) {
    if (e.which < 32) {
      return null;
    }
    return String.fromCharCode(e.which);
  }
  return null;
};

const md =
  typeof window !== 'undefined' &&
  new MobileDetect(window.navigator.userAgent);

export const isMobile = md && !!md.mobile();

export const formatNumberDecimalValue = (
  stringValue: string | null,
  frictionLength?: number,
  isNegative?: boolean,
) => {
  if (stringValue === null) {
    return '';
  }

  const minus =
    !isNegative || stringValue.indexOf('-') < 0 ? '' : '-';
  const preparedValue = stringValue
    .replace(',', '.')
    .replace(/[^\d\\.]/g, '')
    .replace(/^0+/, '0')
    .replace(/^0([\d\\.]+)$/, '$1');
  const dotIndex = preparedValue.indexOf('.');
  const integerValue = preparedValue.substring(
    0,
    dotIndex < 0 ? preparedValue.length : dotIndex,
  );

  const decimalValue =
    dotIndex < 0
      ? ''
      : preparedValue
          .substring(dotIndex + 1)
          .substring(0, frictionLength);

  if (!integerValue.length && dotIndex > -1) {
    return `${minus}0.${decimalValue}`;
  }
  if (!integerValue.length) {
    return minus;
  }
  if (integerValue.length && dotIndex > -1) {
    return `${minus}${integerValue}.${decimalValue}`;
  }
  return `${minus}${integerValue}`;
};
