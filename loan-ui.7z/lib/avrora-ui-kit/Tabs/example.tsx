import React, { useState } from 'react';

// import { PreviewComponent } from '../../SystemComponents/Playground';
// import { Border, DescExample, TitleExample } from '../../SystemComponents/Blocks/style';

import Tabs, { IItem } from './Tabs';

// const code = `
//   import React, { useState } from 'react';
//   import { Tabs } from '@holism/core';

//   const list: IItem[] = [
//     { id: 'firstTab', label: 'VISA Gold', isActive: false },
//     { id: 'secondTab', label: 'VISA Platinum', isActive: true },
//     { id: 'thirdTab', label: 'VISA Signature', isActive: false }
//   ];

//   () => {
//     const [list, setList] = useState(list);
//     return (
//       <Tabs
//         list={list}
//         onChange={({ id, isActive, label }: IItem) => {
//           console.log('selected tab: ', { id, isActive, label });
//           setList(
//             list.map(item =>
//               item.id === id ? { id, isActive: true, label } : { ...item, isActive: false }
//             )
//           );
//         }}
//       />
//     );
//   };
// `;

// const interfaces = `
// interface IItem {
//   id: string;
//   label: string;
//   isActive: boolean;
// }

// interface IProps {
//   list: IItem[];
//   onChange: (item: IItem) => void;
//   width?: string;
//   className?: string;
// }
// `;

const testList: IItem[] = [
  { id: 'firstTab', label: 'VISA Gold', isActive: false },
  { id: 'secondTab', label: 'VISA Platinum', isActive: true },
  { id: 'thirdTab', label: 'VISA Signature', isActive: false },
];

const Preview = () => {
  const [list, setList] = useState(testList);

  return (
    <>
      {/* <TitleExample>Описание</TitleExample>
      <DescExample>
        Данный компонент используется для группировки контента и помогают в навигации. Рекомендуется
        использовать для второстепенной навигации.
      </DescExample>
      <Border flex={true}> */}
      {/* <Tabs
        list={list}
        onChange={({ id, isActive, label }: IItem) => {
          console.log('selected tab: ', { id, isActive, label });
          setList(
            list.map((item) =>
              item.id === id
                ? { id, isActive: true, label }
                : { ...item, isActive: false },
            ),
          );
        }}
      /> */}
      {/* </Border> */}
    </>
  );
};

const Example = () => (
  <div>
    <Preview />
    {/* <PreviewComponent
      previewComponent={<Preview />}
      codeComponent={code}
      interfaceComponent={interfaces}
    /> */}
  </div>
);

export const Info = {
  name: 'Tabs',
  component: Example,
};
