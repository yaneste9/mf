import styled from 'styled-components';

import { INNERSHADOWS } from '../palette';
import { ITheme, DefaultTheme } from '../palette/variables';

interface ITab {
  isActive: boolean;
  theme: ITheme;
}

interface IUnderLine {
  left: number;
  width: number;
  theme: ITheme;
}

interface IWrapper {
  width?: string;
  theme: ITheme;
}

export const Wrapper = styled.div<IWrapper>`
  font-family: ${({ theme }: IWrapper) =>
    theme.typography.fontFamily};
  overflow-x: hidden;
  position: relative;
  display: flex;
  width: ${({ width }) => width || '100%'};

  > *:last-child {
    margin-right: 0px;
  }

  &::before {
    position: absolute;
    bottom: 0;
    content: '';
    height: 2px;
    width: 100%;
    background-color: ${({ theme }: IWrapper) =>
      theme.colors.blue[30]};
  }
`;

Wrapper.defaultProps = {
  theme: DefaultTheme,
};

export const TabContent = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;

  &:focus {
    outline: none;
  }
`;

export const Tab = styled.div<ITab>`
  display: flex;
  align-items: center;
  height: 40px;
  margin-right: 32px;
  ${({ theme }: ITab) => `
    line-height: ${theme.typography.lineHeight2};
    font-size: ${theme.typography.fontSize1};
  `}
  color: ${({ isActive, theme }: ITab) =>
    isActive ? theme.colors.blue[80] : theme.colors.grey[90]};
  transition: all 0.2s;
  cursor: pointer;

  &:hover {
    color: ${({ theme }: ITab) => theme.colors.blue[20]};
  }

  &:focus {
    outline: none;
  }

  &:focus > ${TabContent} {
    box-shadow: ${({ theme }) =>
      `inset ${INNERSHADOWS.shadowSmall} ${theme.colors.greyMouse}`};
  }

  user-select: none;
`;

Tab.defaultProps = {
  theme: DefaultTheme,
};

export const Underline = styled.div<IUnderLine>`
  position: absolute;
  z-index: 1;
  bottom: 0;
  left: ${({ left }) => left}px;
  width: ${({ width }) => width}px;
  display: ${({ width }) => (width ? 'block' : 'none')};
  height: 2px;
  background-color: ${({ theme }: IUnderLine) =>
    theme.colors.blue[80]};
  transition: all 0.2s ease-out;
`;

Underline.defaultProps = {
  theme: DefaultTheme,
};
