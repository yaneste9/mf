// import React, {
//   createRef,
//   Component,
//   KeyboardEvent,
//   RefObject,
//   GetDerivedStateFromProps,
// } from 'react';

// import { KEY_CODES } from '../common';

// import { Wrapper, Tab, Underline, TabContent } from './style';

// export interface IItem {
//   id: string;
//   label: string;
//   isActive: boolean;
// }

// export interface IProps {
//   list: IItem[];
//   onChange: (item: IItem) => void;
//   width?: string;
//   className?: string;
// }

// export interface ITab extends IItem {
//   ref: RefObject<HTMLDivElement>;
// }

// export interface IState {
//   list: IItem[];
//   tabs: ITab[];
//   underlineRect: { left: number; width: number };
// }

// class Tabs extends Component<IProps, IState> {
//   state: IState = {
//     list: [],
//     tabs: [],
//     underlineRect: {
//       left: 0,
//       width: 0,
//     },
//   };

//   componentDidMount() {
//     const { list } = this.props;
//     const tabs = list.map((item) => ({
//       ...item,
//       ref: createRef<HTMLDivElement>(),
//     }));
//     this.setState({ tabs, list });
//   }

//   static getDerivedStateFromProps: GetDerivedStateFromProps<
//     IProps,
//     IState
//   > = (nextProps, prevState) => {
//     const { list } = nextProps;
//     const { tabs, list: prevList } = prevState;

//     if (prevList !== list) {
//       let newTabs = list.map(({ id, label, isActive }: IItem) => {
//         const tab = tabs.find((tab: ITab) => tab.id === id);
//         return tab
//           ? { ...tab, isActive }
//           : { id, label, isActive, ref: createRef<HTMLDivElement>() };
//       });
//       const isActiveMultiple =
//         newTabs.filter((tab: ITab) => tab.isActive).length > 1;
//       if (isActiveMultiple) {
//         const firstActiveTab = newTabs.find(
//           (tab: ITab) => tab.isActive,
//         );
//         newTabs = newTabs.map((tab: ITab) =>
//           tab.id === firstActiveTab!.id
//             ? tab
//             : { ...tab, isActive: false },
//         );
//       }

//       return { tabs: newTabs, list };
//     }
//     return null;
//   };

//   componentDidUpdate() {
//     const {
//       tabs,
//       underlineRect: { left, width },
//     } = this.state;
//     const activeTab = tabs.find((tab: ITab) => tab.isActive);
//     const activeRef = activeTab && activeTab.ref.current;

//     if (
//       activeRef &&
//       (activeRef.offsetLeft !== left ||
//         activeRef.clientWidth !== width)
//     ) {
//       this.setState({
//         underlineRect: {
//           left: activeRef.offsetLeft,
//           width: activeRef.clientWidth,
//         },
//       });
//     }
//   }

//   handleOnClick(label: string, id: string) {
//     const { onChange } = this.props;
//     const { tabs } = this.state;
//     const newTabs = tabs.map((tab: ITab) =>
//       tab.id === id
//         ? { ...tab, isActive: true }
//         : { ...tab, isActive: false },
//     );

//     onChange && onChange({ id, label, isActive: true });
//     this.setState({ tabs: newTabs });
//   }

//   handleOnPress = (
//     event: KeyboardEvent,
//     label: string,
//     id: string,
//   ) => {
//     const { onChange } = this.props;
//     const { tabs } = this.state;
//     if (
//       event.keyCode === KEY_CODES.ENTER ||
//       event.keyCode === KEY_CODES.SPACEBAR
//     ) {
//       const newTabs = tabs.map((tab: ITab) =>
//         tab.id === id
//           ? { ...tab, isActive: true }
//           : { ...tab, isActive: false },
//       );
//       onChange && onChange({ id, label, isActive: true });
//       this.setState({ tabs: newTabs });
//     }
//   };

//   render() {
//     const { width, className } = this.props;
//     const {
//       tabs,
//       underlineRect: { left, width: underlineWidth },
//     } = this.state;

//     return (
//       <Wrapper width={width} className={className}>
//         <Underline left={left} width={underlineWidth} />
//         {tabs.map(({ isActive, label, id, ref }: ITab) => (
//           <Tab
//             data-element="tab-item"
//             tabIndex={1}
//             ref={ref}
//             onClick={() => this.handleOnClick(label, id)}
//             onKeyUp={(e: KeyboardEvent) =>
//               this.handleOnPress(e, label, id)
//             }
//             key={id}
//             isActive={isActive}
//           >
//             <TabContent data-element="tab-label" tabIndex={-1}>
//               {label}
//             </TabContent>
//           </Tab>
//         ))}
//       </Wrapper>
//     );
//   }
// }

// export default Tabs;
