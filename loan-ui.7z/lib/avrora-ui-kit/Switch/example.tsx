import React, { useState } from 'react';

import { DocsComponent } from '../../app/components/Playground';
import {
  CodeComponent,
  DemoComponent,
} from '../../app/components/Demo';
import RadioButton from '../RadioButton/RadioButton';

import Switch from './Switch';

const code = `
  () => {
    const [isActive, setActive] = useState(true);

    return(
      <Switch
        label={isActive ? 'Включено' : 'Выключено'}
        checked={isActive}
        onChange={(evt: React.ChangeEvent<any>, isChecked) => {
          setActive(isChecked);
        }}
      />
    );
  }
`;

const Preview = () => {
  const [isActiveFirst, setActiveFirst] = useState(true);
  // const [code, setCode] = useState('');
  // const [comp, setComp] = useState();
  // const [isActiveSecond, setActiveSecond] = useState(false);

  return (
    <>
      <div>
        <DemoComponent>
          <>
            <Switch
              label={'Toggle'}
              checked={isActiveFirst}
              onChange={(evt: React.ChangeEvent<any>, isChecked) => {
                setActiveFirst(isChecked);
              }}
            />
            <RadioButton
              label="Москва"
              checked={isActiveFirst}
              onChange={(a, b) => {
                console.log(b);
                setActiveFirst(!isActiveFirst);
              }}
              value="test"
            />
            <RadioButton
              label="Москва"
              dimension="small"
              checked={isActiveFirst}
              onChange={(a, b) => {
                console.log(b);
                setActiveFirst(!isActiveFirst);
              }}
              value="test"
            />
            <RadioButton
              label="Москва"
              dimension="small"
              disabled={true}
              checked={true}
              value="test"
            />
          </>
        </DemoComponent>
      </div>
      <CodeComponent code={code} />
    </>
  );
};

const Example = () => (
  <div>
    <DocsComponent demoComponent={<Preview />} />
  </div>
);

export const Info = {
  name: 'Switch',
  component: Example,
};
