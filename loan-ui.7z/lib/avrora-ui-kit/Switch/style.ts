import styled, { css } from 'styled-components';
import { size } from 'polished';

import { DefaultTheme, ITheme } from '../palette/variables';

interface IProps {
  switchOn: boolean;
  disabled: boolean;
  labelPosition?: 'right' | 'left';
  dimension: 'big' | 'small';
}

interface ISwitch extends Partial<IProps> {
  theme: ITheme;
}

export const SwitchLabel = styled.div<ISwitch>`
  display: inline-block;
  cursor: pointer;
  ${({ disabled, theme }: ISwitch) =>
    disabled &&
    css`
      color: ${theme.colors.grey[30]};
      pointer-events: none;
    `}
`;

SwitchLabel.defaultProps = {
  theme: DefaultTheme,
};

export const SwitchWrapper = styled.div<ISwitch>`
  display: flex;
  align-items: center;
`;

export const SwitchSlider = styled.div<ISwitch>`
  object-fit: contain;
  ${({ dimension }) =>
    dimension === 'big'
      ? size('20px', '40px')
      : size('16px', '32px')};
  display: inline-block;
  cursor: pointer;

  ${({ switchOn, disabled, theme }: ISwitch) =>
    disabled
      ? `
          background-color: ${theme.colors.grey[30]};
          pointer-events: none;
        `
      : switchOn
      ? `
      background-color: ${theme.colors.blue[60]};
      &:hover {
        background-color: ${theme.colors.blue[70]};
        &:before {
          border-color: ${theme.colors.blue[70]};
        }
      }
    `
      : `
    background-color: ${theme.colors.grey[50]};
    &:hover {
      background-color: ${theme.colors.grey[60]};
      &:before {
        border-color: ${theme.colors.grey[60]};
      }
    }
  `};

  transition: 0.2s;
  border-radius: ${({ dimension }) =>
    dimension === 'big' ? 10 : 12}px;
  ${({ labelPosition }) =>
    labelPosition === 'right'
      ? `margin-right: 8px;`
      : `margin-left: 8px;`}
  position: relative;
  text-align: left;
  box-sizing: content-box !important;

  &:before {
    content: '';
    position: relative;
    display: inline-block;
    ${({ dimension }) =>
      dimension === 'big'
        ? size('20px', '20px')
        : size('16px', '16px')};
    background-color: ${({ theme }: ISwitch) =>
      theme.colors.grey.white};
    transition: 0.2s;
    border-radius: 50%;
    border: solid 2px
      ${({ switchOn, disabled, theme }: ISwitch) =>
        disabled
          ? theme.colors.grey[30]
          : switchOn
          ? theme.colors.blue[60]
          : theme.colors.grey[50]};
    box-sizing: border-box;
  }
`;

SwitchSlider.defaultProps = {
  theme: DefaultTheme,
};

export const SwitchInput = styled.input<ISwitch>`
  display: none;
  &:checked + ${SwitchSlider} {
    &:before {
      transform: ${({ dimension }) =>
        dimension === 'big'
          ? 'translateX(20px);'
          : 'translateX(16px);'};
    }
  }
`;

export const SwitchComponent = styled.div<ISwitch>`
  font-family: ${({ theme }: ISwitch) => theme.typography.fontFamily};
  display: flex;
  align-items: center;
`;

SwitchComponent.defaultProps = {
  theme: DefaultTheme,
};
