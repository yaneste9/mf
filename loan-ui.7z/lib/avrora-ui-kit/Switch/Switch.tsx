import React, { useState } from 'react';

import {
  SwitchComponent,
  SwitchLabel,
  SwitchWrapper,
  SwitchSlider,
  SwitchInput,
} from './style';

export interface IProps {
  checked?: boolean;
  label?: string;
  labelPosition?: 'right' | 'left';
  onChange: (evt: React.ChangeEvent<any>, checked: boolean) => void;
  disabled?: any;
  className?: string;
  dimension?: 'big' | 'small';
}

const Switch = (props: IProps) => {
  const [isChecked, toggleCheck] = useState(props.checked);

  const {
    label,
    labelPosition,
    disabled,
    className,
    dimension,
  } = props;

  const handleOnChange = (evt: React.ChangeEvent<any>) => {
    const { onChange, disabled } = props;
    if (!disabled) {
      toggleCheck(!isChecked);
      onChange(evt, !isChecked);
    }
  };

  return (
    <SwitchComponent className={className}>
      {label && labelPosition === 'left' && (
        <SwitchLabel
          data-element="switch-label"
          disabled={disabled}
          onClick={handleOnChange}
        >
          {label}
        </SwitchLabel>
      )}
      <SwitchWrapper>
        <SwitchInput
          data-element="switch-input"
          type="checkbox"
          checked={isChecked}
          // name="checkbox"
          readOnly={true}
          dimension={dimension}
        />
        <SwitchSlider
          data-element="switch-slider"
          switchOn={isChecked}
          disabled={disabled}
          labelPosition={labelPosition}
          dimension={dimension}
          onClick={handleOnChange}
        />
      </SwitchWrapper>

      {label && labelPosition === 'right' && (
        <SwitchLabel
          data-element="switch-label"
          disabled={disabled}
          onClick={handleOnChange}
        >
          {label}
        </SwitchLabel>
      )}
    </SwitchComponent>
  );
};

Switch.defaultProps = {
  dimension: 'big',
  labelPosition: 'left',
  disabled: false,
};

export default Switch;

// ? name, id
