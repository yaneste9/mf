const merge = require('webpack-merge');
const CopyPlugin = require('copy-webpack-plugin');
const path = require('path');
const autoprefixer = require('autoprefixer');
const atImport = require('postcss-import');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const postcssCustomProperties = require('postcss-custom-properties');
const baseConfig = require('../base.js');

const cssModulesLocalIdentName = '[local]-[hash:base64:5]';

const moduleConfig = merge(baseConfig, {
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
          },
          {
            loader: 'css-loader',
            options: {
              modules: {
                localIdentName: cssModulesLocalIdentName,
              },
            },
          },
          {
            loader: 'postcss-loader',
            options: {
              plugins: [
                autoprefixer(),
                atImport(),
                postcssCustomProperties({
                  preserve: true,
                }),
              ],
            },
          },
        ],
      },
    ],
  },
});

const commonConfig = {
  plugins: [
    new MiniCssExtractPlugin({
      path: path.resolve(__dirname, '../../../dist'),
      filename: 'public/[name].css',
    }),
    new CopyPlugin({
      patterns: [
        {
          from: path.resolve(__dirname, '../../../src/assets'),
          to: path.resolve(__dirname, '../../../dist/public/assets'),
        },
      ],
    }),
  ],
};

module.exports = { moduleConfig, commonConfig };
