const { ModuleFederationPlugin } = require('webpack').container;
const postcssCustomProperties = require('postcss-custom-properties');
const atImport = require('postcss-import');
const autoprefixer = require('autoprefixer');
const path = require('path');
const merge = require('webpack-merge');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const baseConfig = require('../base.js');

const deps = require('./../../../package.json').dependencies; // dependencies


const cssModulesLocalIdentName = '[local]-[hash:base64:5]';

const moduleConfig = merge(baseConfig, {
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
          },
          {
            loader: 'css-loader',
            options: {
              modules: {
                localIdentName: cssModulesLocalIdentName,
              },
            },
          },
          {
            loader: 'postcss-loader',
            options: {
              plugins: [
                autoprefixer(),
                atImport(),
                postcssCustomProperties({
                  preserve: true,
                }),
              ],
            },
          },
        ],
      },
    ],
  },
});

const commonConfig = {
  plugins: [
    new ModuleFederationPlugin({
      name: 'appLoanUI',
      library: { type: 'var', name: 'appLoanUI' },
      filename: 'remoteEntry.js',
      exposes: {
        './LoanUI': './src/client/LoanUI',
      },
      shared: {
        ...deps,
        react: {
          singleton: true,
        },
        'react-dom': {
          singleton: true,
        },
      },
    }),
    new MiniCssExtractPlugin({
      path: path.resolve(__dirname, '../../../dist/'),
      filename: '[name].css',
    }),
  ],
};

module.exports = { moduleConfig, commonConfig };
