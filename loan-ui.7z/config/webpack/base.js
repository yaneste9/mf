const path = require('path');

const baseConfig = {
  stats: 'minimal',
  module: {
    rules: [
      {
        test: /bootstrap\.tsx$/,
        loader: 'bundle-loader',
        options: {
          lazy: true,
        },
      },
      {
        test: /\.(ts|tsx)$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        options: {
          presets: [
            '@babel/preset-react',
            '@babel/preset-typescript',
          ],
        },
      },
      {
        test: /\.(png|jpe?g|gif|svg)$/i,
        use: [
          {
            loader: 'file-loader',
          },
        ],
      },
    ],
  },
  resolve: {
    extensions: ['*', '.ts', '.tsx', '.js', '.jsx'],
  },
  watchOptions: {
    ignored: [
      '../../../dist/**',
      '../../../lib/**',
      '../../../node_modules/**',
      '../../../config/**',
      '../../../src/assets/**',
    ],
  },
};

module.exports = baseConfig;
