import { RootState } from './root-reducer';
import { IUniversalRequest } from './modules/universal-request/types';

export const selectUniversalRequest = (
  state: RootState,
): IUniversalRequest => state.universalRequest.data;
