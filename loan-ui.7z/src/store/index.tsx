import * as redux from 'redux';
import { batchDispatchMiddleware } from 'redux-batched-actions';
import thunk from 'redux-thunk';
import rootReducers from './root-reducer';

const createStore = (
  preloadState?: Record<string, unknown>,
): redux.Store => {
  const store = redux.createStore(
    rootReducers,
    preloadState,
    redux.applyMiddleware(thunk, batchDispatchMiddleware),
  );

  return store;
};

const globalStore = createStore();

export default globalStore;
