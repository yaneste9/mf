import { combineReducers } from 'redux';
import universalRequest from './modules/universal-request/reducer';

const rootReducer = combineReducers({
  universalRequest,
});

export type RootState = ReturnType<typeof rootReducer>;

export default rootReducer;
