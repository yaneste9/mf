export const ADD_UNIVERSAL_REQUEST = 'ADD_UNIVERSAL_REQUEST';

export interface IUniversalRequest {
  firstName: string;
  lastName: string;
  patronimic: string;
}

export interface UniversalRequestState {
  data: IUniversalRequest;
}

interface IAddUniversalRequestAction {
  type: typeof ADD_UNIVERSAL_REQUEST;
  payload: IUniversalRequest;
}

export type TAddUniversalRequestAction = IAddUniversalRequestAction;
