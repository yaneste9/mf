import {
  ADD_UNIVERSAL_REQUEST,
  TAddUniversalRequestAction,
  UniversalRequestState,
} from './types';

const initialState: UniversalRequestState = {
  data: {
    firstName: '',
    lastName: '',
    patronimic: '',
  },
};

export default (
  state = initialState,
  action: TAddUniversalRequestAction,
): UniversalRequestState => {
  switch (action.type) {
    case ADD_UNIVERSAL_REQUEST:
      return {
        ...state,
        data: {
          ...action.payload,
        },
      };

    default:
      return state;
  }
};
