import {
  ADD_UNIVERSAL_REQUEST,
  TAddUniversalRequestAction,
  IUniversalRequest,
} from './types';
import { TAction } from '../../types';
import { api } from '../../../api';

const AddUniversalRequest = (
  universalRequest: IUniversalRequest,
): TAddUniversalRequestAction => ({
  type: ADD_UNIVERSAL_REQUEST,
  payload: universalRequest,
});

export const getUniversalRequest = (): TAction => async (
  dispatch,
): Promise<void> => {
  const response = await api.getUniversalRequest();

  if (response.data) {
    dispatch(AddUniversalRequest(response.data));
  }
};
