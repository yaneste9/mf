import { ThunkAction, ThunkDispatch } from 'redux-thunk';
import { Action } from 'redux';
import { RootState } from './root-reducer';

export type TAction = ThunkAction<
  void,
  RootState,
  unknown,
  Action<string>
>;
export type TDispatch = ThunkDispatch<RootState, unknown, Action>;
