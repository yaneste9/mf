import { AxiosResponse } from 'axios';
import { Api } from '../../api';
import { ResponseData } from '../../types';
import { IUniversalRequest } from '../../../store/modules/universal-request/types';

import getUniversalRequestMock from './mock/get-universal-request.json';
import postUniversalRequestMock from './mock/post-universal-request.json';

export const MethodsUniversalRequest = {
  getUniversalRequest: {
    path: '/universal-request/',
    mock: getUniversalRequestMock,
  },
  postUniversalRequest: {
    path: '/universal-request/',
    mock: postUniversalRequestMock,
  },
};

export class UniversalRequest extends Api {
  async getUniversalRequest(): Promise<
    AxiosResponse<ResponseData<IUniversalRequest>>
  > {
    const response = await this.axios.get<
      ResponseData<IUniversalRequest>
    >(MethodsUniversalRequest.getUniversalRequest.path);
    return response;
  }
}
