import config from './config';
import {
  UniversalRequest,
  MethodsUniversalRequest,
} from './api-routers/universal-request';

export const combineApiRouters = { ...MethodsUniversalRequest };

export const api = new UniversalRequest(
  `${config.serviceHost}${config.apiRoot}`,
);
