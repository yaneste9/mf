import Axios, { AxiosInstance } from 'axios';

export class Api {
  public axios: AxiosInstance;

  constructor(baseURL: string) {
    this.axios = Axios.create({ baseURL });
  }

  onError(callback: (error: Error) => void): number {
    return this.axios.interceptors.response.use(
      undefined,
      (error) => {
        if (!error || !error.response || !error.response.data) {
          callback(error);
        }

        callback(new Error(error.response.data.status));

        return Promise.reject(error);
      },
    );
  }
}
