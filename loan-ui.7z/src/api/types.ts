export type ResponseData<T extends {} = {}> = T & {
  code: number;
  status: string;
};
