export default {
  serviceHost: `http://${
    typeof window !== 'undefined'
      ? window.location.hostname
      : 'localhost'
  }:8080`,
  apiRoot: '/api/v1',
};
