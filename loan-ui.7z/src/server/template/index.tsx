import * as redux from 'redux';
import { Provider } from 'react-redux';
import * as React from 'react';
import { StaticRouter } from 'react-router-dom';
import RootRouter from '../../pages';
import Layout from './layout';

export interface TemplateProps {
  location: string;
  store: redux.Store;
  staticVersion: number;
}

const Template: React.FC<TemplateProps> = ({
  location,
  store,
  staticVersion,
}) => (
  <>
    <Layout staticVersion={staticVersion} />
    {/* <Provider store={store}>
    <Layout staticVersion={staticVersion}>
      <StaticRouter location={location}>
        <RootRouter />
      </StaticRouter>
    </Layout>
  </Provider> */}
  </>
);

export default Template;
