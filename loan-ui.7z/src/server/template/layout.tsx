import * as React from 'react';

export interface LayoutProps {
  children: React.ReactNode;
  staticVersion: number;
}

const Layout: React.FC<LayoutProps> = ({
  children,
  staticVersion,
}) => (
  <html lang="en">
    <head>
      <meta charSet="UTF-8" />
      <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
      />
      <meta httpEquiv="X-UA-Compatible" content="ie=edge" />

      <link
        href="https://fonts.googleapis.com/css?family=Inter:100,200,300,400,500,600,700,800,900&subset=cyrillic,cyrillic-ext,latin,latin-ext"
        rel="stylesheet"
        type="text/css"
      />
      <link rel="stylesheet" href={`/main.css?${staticVersion}`} />

      <title>VTB</title>
    </head>
    <body>
      <div className="app-container">{children}</div>
    </body>

    <script src={`/client.js?${staticVersion}`} />
  </html>
);

export default Layout;
