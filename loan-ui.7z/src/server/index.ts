import express from 'express';
import routes from './routers';
import apiConfig from '../api/config';
import { combineApiRouters } from '../api';

const app = express();
const envApp = process.env.APP;

if (envApp === 'production') {
  // TODO Реализовать продакшен сборку
  // eslint-disable-next-line no-console
  console.log('production');
}

// eslint-disable-next-line
Object.values(combineApiRouters).map((endpoints) => {
  try {
    let { method } = endpoints.mock;
    method = method.toLowerCase();

    const path = apiConfig.apiRoot + endpoints.path;
    const { status, body } = endpoints.mock;

    // eslint-disable-next-line
    (app as any)[method](path, (req: object, res: any) => {
      res.status(status.code).send(body);
    });
  } catch (error) {
    //
  }
});

app.use(express.static('dist/public'));
app.use(routes);

app.listen(8080);
