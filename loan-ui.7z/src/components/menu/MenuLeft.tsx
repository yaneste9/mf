import * as React from 'react';
import { Link } from 'react-router-dom';
import logo from './assets/vtb-logo.svg';
import search from './assets/left-menu/search.svg';
import indexPage from './assets/left-menu/index-page.svg';
import taskPage from './assets/left-menu/task-page.svg';
import clientPage from './assets/left-menu/client-page.svg';
import servicesPage from './assets/left-menu/services-page.svg';

import control from './assets/top-menu/control.svg';
import send from './assets/top-menu/send.svg';
import suo from './assets/top-menu/suo.svg';
import wiki from './assets/top-menu/wiki.svg';
import pdq from './assets/top-menu/pdq.svg';

import styles from './styles.css';

export interface LayoutAuthProps {
  children: React.ReactElement;
}

const MenuLeft: React.FC<LayoutAuthProps> = ({
  children,
}): React.ReactElement => (
  <div className={styles.box}>
    <div className={styles.leftMenu}>
      <Link to="/">
        <img src={logo} alt="" className={styles.logo} />
      </Link>
      <img src={search} alt="" />
      <img src={indexPage} alt="" />
      <img src={taskPage} alt="" />
      <img src={clientPage} alt="" />
      <img src={servicesPage} alt="" />
    </div>
    <div className={styles.topMenu}>
      <div className={styles.topMenuPanel}>
        <img src={control} alt="" />
        <img src={suo} alt="" />
        <img src={send} alt="" className={styles.topMenuBox} />
        <img src={wiki} alt="" className={styles.topMenuBox} />
        <img src={pdq} alt="" className={styles.topMenuBox} />
      </div>
    </div>
    <div>
      <div className={styles.content}>{children}</div>
    </div>
  </div>
);

export default MenuLeft;
