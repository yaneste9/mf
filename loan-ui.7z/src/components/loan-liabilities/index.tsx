import React from 'react';
import cn from 'classnames';
import styles from './styles.css';

interface Data {
  labels: string[];
  rows: Array<string[]>;
}

export interface ILoanLiabilities {
  liabilitiesData: Data;
  className?: string;
}

const LoanLiabilities: React.FC<ILoanLiabilities> = ({
  liabilitiesData,
  className,
}) => {
  const labels = liabilitiesData.labels.map(
    (label: string, index) => {
      return (
        <div className={styles.label} key={label + index}>
          {label}
        </div>
      );
    },
  );

  const rows = liabilitiesData.rows.map((row: Array<string>) => {
    return (
      <div className={styles.row} key={row[2]}>
        {row.map((item: string) => (
          <div className={styles.item} key={item}>
            {item}
          </div>
        ))}
      </div>
    );
  });

  return (
    <div className={cn(styles.liabilities__container, className)}>
      <div className={styles.labels}>{labels}</div>
      <div className={styles.rows}>{rows}</div>
    </div>
  );
};

export default LoanLiabilities;
