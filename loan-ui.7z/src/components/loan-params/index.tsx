import React from 'react';
import cn from 'classnames';
import styles from './styles.css';

interface IRefinancing {
  main: Array<{
    label: string;
    value: string;
  }>;
  auxiliary: {
    'preferential-treatment': Array<{
      label: string;
      value: string;
    }>;
    insurance: Array<{
      label: string;
      value: string;
    }>;
  };
}

export interface ILoanParams {
  refinancingData: IRefinancing;
  className?: string;
}

const LoanParams: React.FC<ILoanParams> = ({
  refinancingData,
  className,
}) => {
  const mainParams = refinancingData.main.map(
    (item: { label: string; value: string }, index) => {
      return (
        <div className={styles.item} key={item.label + index}>
          <div className={styles.label}>{item.label}</div>
          <div className={styles.value}>{item.value}</div>
        </div>
      );
    },
  );
  const preferentialTreatmentParams = refinancingData.auxiliary[
    'preferential-treatment'
  ].map((item: { label: string; value: string }, index) => {
    return (
      <div className={styles.item} key={item.label + index}>
        <div className={styles.label}>{item.label}</div>
        <div className={styles.value}>{item.value}</div>
      </div>
    );
  });
  const insuranceParams = refinancingData.auxiliary.insurance.map(
    (item: { label: string; value: string }, index) => {
      return (
        <div className={styles.item} key={item.label + index}>
          <div className={styles.label}>{item.label}</div>
          <div className={styles.value}>{item.value}</div>
        </div>
      );
    },
  );

  return (
    <div className={cn(styles.loan__container, className)}>
      <div className={styles['main-params']}>{mainParams}</div>
      <div className={styles.auxiliary}>
        <div className={styles['preferential-treatment']}>
          <span>Льготный платеж по кредиту:</span>
          <div className={styles['preferential-treatment-params']}>
            {preferentialTreatmentParams}
          </div>
        </div>
        <div className={styles.insurance}>
          <span>Страховка:</span>
          <div className={styles['insurance-params']}>
            {insuranceParams}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoanParams;
