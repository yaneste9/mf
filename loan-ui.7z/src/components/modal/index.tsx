import React, { ReactElement } from 'react';
import Input from '../../ui/Input';
// import InputRange from '../../ui/input-range';
import styles from './style.css';

export interface IProps {
  modalIsOpen: boolean;
  closeModal(): void;
}

const Modal = (props: IProps): ReactElement => {
  const { modalIsOpen, closeModal } = props;

  if (!modalIsOpen) {
    return null;
  }

  return (
    <>
      <div className={styles.shadow} />
      <div className={styles.modal}>
        <div className={styles.wrapper}>
          {/* eslint-disable-next-line */}
          <div className={styles.closeIcon} onClick={closeModal} />
          <div className={styles.content}>
            <div className={styles.title}>
              Список устройств кли Copy 3
            </div>
            <div className={styles.grid}>
              <div>
                <Input label="Наименование банка" />
              </div>
              <div>
                <Input label="БИК" />
              </div>

              <div>
                <Input label="№ текущего счета" />
              </div>
              <div>
                <Input
                  label="Дата заключения кредитного договора"
                  value="12.05.2016"
                />
              </div>

              <div>
                <Input label="Первоначальная сумма кредита" />
              </div>
              <div>
                {/* <InputRange
                  min="0"
                  max="25000000"
                  value="50000"
                  label="Сумма задолженности"
                  asterisk
                /> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Modal;
