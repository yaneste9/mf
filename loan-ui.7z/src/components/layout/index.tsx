import React from 'react';
import Menu from '../menu';
import './styles.css';

export interface LayoutAuthProps {
  children: React.ReactElement;
}

const LayoutAuth: React.FC<LayoutAuthProps> = ({
  children,
}): React.ReactElement => (
  <>
    <Menu>{children}</Menu>
  </>
);

export default LayoutAuth;
