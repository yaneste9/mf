import React, { ReactNode } from 'react';
import cn from 'classnames';
import * as styles from './styles.css';

interface ICard {
  title: string;
  children: ReactNode;
  className?: string;
}

const Card: React.FC<ICard> = ({ title, children, className }) => {
  return (
    <div className={cn(styles.card, className)}>
      <div className={styles.title}>{title}</div>
      <div className={styles.children}>{children}</div>
    </div>
  );
};

export default Card;
