/* eslint-disable */
import React from 'react';
import cn from 'classnames';
import styles from './styles.css';

interface Props {
  value?: string;
  color?: string;
  onClick?(): void;
  ui?: 'default' | 'avrora';
}

const Button = (props: Props): React.ReactElement => {
  const { value, ui, onClick, color } = props;

  if (ui === 'avrora') {
    return null;
  }

  return (
    <button
      type="button"
      className={cn(styles.button, styles[color])}
      onClick={onClick}
    >
      {value}
    </button>
  );
};

export default Button;
