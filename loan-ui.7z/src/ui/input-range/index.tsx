import React, { useEffect, useState } from 'react';
import cn from 'classnames';
import MaskedInput from 'react-text-mask';
import NumberFormat from 'react-number-format';
import styles from './styles.css';
import {
  clearCurrencyFormat,
  createCurrencyMask,
} from '../../utils/helpers';
import { Currency } from '../../utils/constants';

export interface IInputRange {
  id: string;
  min: string;
  max: string;
  value: string;
  label: string;
  onChange: (val: string) => undefined;
  asterisk?: boolean;
  className?: string;
}
const InputRange: React.FC<IInputRange> = ({
  id,
  min,
  max,
  value,
  label,
  onChange,
  asterisk,
  className,
}) => {
  const [valueState, sevValueState] = useState(value);
  const [progressState, setProgressState] = useState(0);
  const countProgress = (val: number) => {
    return (val / (parseFloat(max) - parseFloat(min))) * 100;
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = clearCurrencyFormat(e.target.value);
    if (parseInt(val, 10) < parseInt(min, 10)) {
      val = min;
    }
    if (parseInt(val, 10) > parseInt(max, 10)) {
      val = max;
    }
    sevValueState(val);
    setProgressState(countProgress(parseFloat(val)));
    onChange(val);
  };
  const setInputRangeProgress = (progress: number) => {
    const inputRange = document.querySelector(
      `#${id}`,
    ) as HTMLElement;
    inputRange.style.setProperty(
      '--webkitProgressPercent',
      `${progress.toString()}%`,
    );
  };
  const countFormattedLength = (str: string): number => {
    return str.length + Math.floor(str.length / 3) + 2;
  };
  useEffect(() => {
    setInputRangeProgress(progressState);
  }, [progressState]);
  return (
    <div className={cn(className, styles['input-range'])}>
      <div className={styles['input-range__container']}>
        <label htmlFor={styles['marked-input']}>
          {label}
          {asterisk ? <span>&nbsp;*</span> : ''}
        </label>
        <MaskedInput
          className={styles['marked-input']}
          maxLength={countFormattedLength(max)}
          mask={createCurrencyMask(
            parseInt(valueState, 10),
            ` ${Currency.RUB}`,
          )}
          value={valueState}
          onChange={handleChange}
        />
        <input
          id={id}
          type="range"
          min={min}
          max={max}
          value={valueState}
          onChange={handleChange}
        />
        <div className={styles.ranges}>
          <NumberFormat
            value={min}
            displayType="text"
            thousandSeparator=" "
          />
          <NumberFormat
            value={max}
            displayType="text"
            thousandSeparator=" "
          />
        </div>
      </div>
    </div>
  );
};
export default InputRange;
