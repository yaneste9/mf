/* eslint-disable */
import React from 'react';
import * as styles from './styles.css';

interface Props {
  label?: string;
  value?: string;
}

const Input = (props: Props): React.ReactElement => {
  const { label, value } = props;

  return (
    <div>
      <label className={styles.label}>{label}</label>
      <input type="text" className={styles.input} value={value} />
    </div>
  );
};

export default Input;
