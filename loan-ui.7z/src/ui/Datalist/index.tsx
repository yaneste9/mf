/* eslint-disable */
import React from 'react';
import * as styles from './styles.css';

interface Props {
  label?: string;
  value?: string;
  onChange?(): void;
}

const Datalist = (props: Props): React.ReactElement => {
  const { label, value } = props;

  return (
    <div>
      <label className={styles.label}>{label}</label>
      <input
        type="text"
        className={styles.input}
        value={value}
        placeholder=""
        readOnly
        defaultValue=""
      />
      <div className={styles.datalist}>
        <div className={styles.option}>123</div>
        <div className={styles.option}>123</div>
        <div className={styles.option}>123</div>
      </div>
    </div>
  );
};

export default Datalist;
