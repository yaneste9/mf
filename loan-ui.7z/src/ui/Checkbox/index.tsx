import React, { useState } from 'react';
import cn from 'classnames';
import * as styles from './styles.css';

interface ICheckbox {
  label: string;
  size: string;
  onSelect: (val: boolean) => undefined;
  checked?: boolean;
  disabled?: boolean;
  indeterminate?: boolean;
  className?: string;
}

const Checkbox: React.FC<ICheckbox> = ({
  label,
  size,
  onSelect,
  checked,
  disabled,
  indeterminate,
  className,
}) => {
  const [checkedState, setCheckedState] = useState(checked);

  const handleSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCheckedState(e.target.checked);
    onSelect(e.target.checked);
  };
  return (
    <div className={cn(className, styles.checkbox)}>
      <input
        id={styles.checkbox}
        type="checkbox"
        checked={checkedState}
        disabled={disabled}
        onChange={handleSelect}
        style={{ display: 'none' }}
      />
      <label
        htmlFor={styles.checkbox}
        className={cn(
          styles.label,
          { [styles['checkmark-small']]: size === 's' },
          { [styles['checkmark-medium']]: size === 'm' },
        )}
      >
        <span className={styles.checkmark}>
          {checkedState && size === 's' && !indeterminate && (
            <svg
              width="10"
              height="7"
              viewBox="0 0 10 7"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M3.50987 6.4444C3.83448 6.74963 4.36777 6.73873 4.68079 6.4226L9.80503 1.19008C10.0833 0.895752 10.0601 0.448808 9.75866 0.187182C9.45723 -0.0744436 8.97031 -0.0635428 8.69207 0.230786L4.06635 4.96185L1.28396 2.34559C0.994125 2.07307 0.507207 2.07307 0.217374 2.34559C-0.0724581 2.61812 -0.0724581 3.07597 0.217374 3.34849L3.50987 6.4444Z" />
            </svg>
          )}
          {checkedState && size === 'm' && !indeterminate && (
            <svg
              width="12"
              height="8"
              viewBox="0 0 12 8"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M4.21184 7.73327C4.60138 8.09955 5.24133 8.08647 5.61695 7.70711L11.766 1.4281C12.0999 1.0749 12.0721 0.538569 11.7104 0.224618C11.3487 -0.0893323 10.7644 -0.0762513 10.4305 0.276943L4.87962 5.95422L1.54075 2.81471C1.19295 2.48768 0.608648 2.48768 0.260849 2.81471C-0.0869497 3.14174 -0.0869497 3.69116 0.260849 4.01819L4.21184 7.73327Z" />
            </svg>
          )}
          {checkedState && size === 's' && indeterminate && (
            <svg
              width="8"
              height="2"
              viewBox="0 0 8 2"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect width="8" height="2" rx="1" />
            </svg>
          )}
          {checkedState && size === 'm' && indeterminate && (
            <svg
              width="10"
              height="2"
              viewBox="0 0 10 2"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect width="10" height="2" rx="1" />
            </svg>
          )}
        </span>
        {label}
      </label>
    </div>
  );
};

export default Checkbox;
