export const themes = {
  colors: {
    BLACK: '#000000',
  },
};
