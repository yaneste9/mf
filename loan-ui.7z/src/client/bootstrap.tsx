import React from 'react';
import { hydrate, render } from 'react-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import store from '../store';
import RootRouter from '../pages';
import LoanUI from './LoanUI';

const appContainer = document.querySelector('.app-container');
const renderMethod = typeof window !== 'undefined' ? render : hydrate;

// renderMethod(<LoanUI />, appContainer);
renderMethod(
  <Provider store={store}>
    <BrowserRouter>
      <RootRouter />
    </BrowserRouter>
  </Provider>,
  appContainer,
);
