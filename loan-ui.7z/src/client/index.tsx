/*eslint-disable */
// @ts-ignore
import bootstrap from './bootstrap';
bootstrap(() => {});
