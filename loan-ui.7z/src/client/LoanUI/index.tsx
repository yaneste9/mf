import React from 'react';
import { hydrate, render } from 'react-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import store from '../../store';
import RootRouter from '../../pages';

const LoanUI = (props: any) => {
  console.log(store);
  console.log(props);

  return (
    <>
      <Provider store={store}>
        <BrowserRouter>
          <RootRouter />
        </BrowserRouter>
      </Provider>
    </>
  );
};

export default LoanUI;
