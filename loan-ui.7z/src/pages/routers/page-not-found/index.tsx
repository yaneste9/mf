import React from 'react';
import * as styles from './styles.css';

const PageNotFound: React.FC = () => (
  <div className={styles.title}>Page Not Found</div>
);

export default PageNotFound;
