import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import groupStyles from '../index-page/styles.css';
import styles from './style.css';

const RequestPage: React.FC = () => {
  const history = useHistory();

  useEffect(() => {
    setTimeout(() => {
      history.push('/request_decision');
    }, 2000);
  }, []);

  return (
    <div>
      <h1>Универсальная заявка</h1>
      <div className={groupStyles.content}>
        <div className={styles.content}>
          <div className={styles.title}>
            Решение по универсальной заявке №154343
          </div>
          <div className={`${styles.title} ${styles.title__report}`}>
            Ожидайте ответ по заявке. *
          </div>
          <span>
            До завершения проверки данных осталось 59 секунд...
          </span>
        </div>
        <div className={styles.box}>
          В случае если проверка занимает больше 15 минут, нажмите
          ссылку Отправить в СПП, для решения проблем по текущей
          ситуации.
        </div>
      </div>
    </div>
  );
};

export default RequestPage;
