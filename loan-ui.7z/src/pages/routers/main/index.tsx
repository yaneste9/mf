import * as paths from '../../const-page-path';
import { RoutersType } from '../../types';
import IndexPage from './index-page';
import RequestPage from './request';
import RequestDecisionPage from './request-decision';
import SignedAgreementPage from './signed-agreement';

const routers: RoutersType = [
  {
    path: paths.INDEX_PAGE_PATH,
    component: IndexPage,
  },
  {
    path: paths.REQUEST_PATH,
    component: RequestPage,
  },
  {
    path: paths.REQUEST_DECISION_PATH,
    component: RequestDecisionPage,
  },
  {
    path: paths.SIGNED_AGREEMENT_PATH,
    component: SignedAgreementPage,
  },
];

export default routers;
