import React from 'react';
import cn from 'classnames';
import styles from './style.css';
import groupStyles from '../index-page/styles.css';
import Button from '../../../../ui/Button';

import activeDocument from './assets/active-document.svg';
import disabledDocument from './assets/disabled-document.svg';
import Checkbox from '../../../../ui/Checkbox';

export interface ISignedAgreementPage {
  className?: string;
}
const SignedAgreementPage: React.FC<ISignedAgreementPage> = (
  className,
) => {
  return (
    <div className={cn(styles['signed-agreement'], className)}>
      <h1>Универсальная заявка</h1>
      <div className={groupStyles.content}>
        <h2>Подпишите кредитный договор с клиентом:</h2>
        <div className={styles.title}>
          Необходимо выбрать способ подписания документов.
        </div>
        <div className={styles['choice-block']}>
          <input type="radio" id="paper" name="signing-method" />
          <label htmlFor="paper">Бумажное</label>
          <input type="radio" id="electronic" name="signing-method" />
          <label htmlFor="electronic">Электронное</label>
        </div>
        <div className={styles.actions__container}>
          <div className={styles.description}>
            Отправьте клиенту запрос в приложение на электронное
            подписание нажав quot; Кредитный договор &ldquo;. После
            этого необходимо подписать с клиентом расписку.
          </div>
          <div className={styles.actions}>
            <div
              className={cn(styles['loan-agreement'], styles.active)}
            >
              <img
                src={activeDocument}
                alt=""
                className={styles.active}
              />
              <span>Кредитный договор</span>
            </div>
            <div
              className={cn(
                styles['sign-a-receipt'],
                styles.disabled,
              )}
            >
              <img
                src={disabledDocument}
                alt=""
                className={styles.disabled}
              />
              <span>Подписать расписку</span>
            </div>
          </div>
        </div>
        <div className={styles.confirmation}>
          <Checkbox
            label="Клиент подписал документы"
            size="m"
            onSelect={() => undefined}
          />
        </div>
        <Button value="Выдать кредит" color="primary" />
      </div>
    </div>
  );
};

export default SignedAgreementPage;
