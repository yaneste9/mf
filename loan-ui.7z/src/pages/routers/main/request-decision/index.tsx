import React, { useState } from 'react';
import cn from 'classnames';
import Button from '../../../../ui/Button';
import Modal from '../../../../components/modal';
import groupStyles from '../index-page/styles.css';
import styles from './style.css';
import Card from '../../../../ui/Card';
import { Tabs } from '../../../../../lib/avrora-ui-kit/index';
import { IItem } from '../../../../../lib/avrora-ui-kit/Tabs/Tabs';
import LoanParams from '../../../../components/loan-params';
import data from '../../../../data/loans-mock-data.json';
import LoanLiabilities from '../../../../components/loan-liabilities';

const list: IItem[] = [
  { id: 'firstTab', label: 'Рефинансирование', isActive: true },
  { id: 'secondTab', label: 'Кредитная карта', isActive: false },
];

const RequestDecisionPage: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [listState] = useState(list);
  const [approvedState, setApprovedState] = useState(false);
  const [preApprovedState, setPreApprovedState] = useState(true);
  const closeModal = () => {
    setIsOpen(false);
  };

  const handleClick = () => {
    setIsOpen(true);
    setApprovedState(!approvedState);
    setPreApprovedState(!preApprovedState);
  };

  return (
    <div className={styles.decision__container}>
      <h1>Универсальная заявка</h1>
      <div className={groupStyles.content}>
        <div className={styles.title__container}>
          <h2>Решение по заявке</h2>
          <div className={cn(styles['approval-notification'])}>
            {approvedState && (
              <div className={styles.approved}>Одобрено</div>
            )}
            {preApprovedState && (
              <div className={styles.preapproved}>
                Предварительно одобрено
              </div>
            )}
          </div>
        </div>
        <div className={styles.description}>
          Теперь подберите продукт клиенту.
        </div>
        <Modal modalIsOpen={isOpen} closeModal={closeModal} />
        <Button
          onClick={() => {
            setIsOpen(true);
          }}
          value="Изменить условия продукта"
          color="secondary"
        />
        <div className={styles.content__container}>
          <Card title="Условия по продуктам:" className={styles.card}>
            {/* <Tabs list={listState} onChange={() => undefined} /> */}
            <LoanParams refinancingData={data.refinancing} />
          </Card>
          <Card
            title="Обязательства по кредитам выбранные для рефинансирования:"
            className={styles.card}
          >
            <LoanLiabilities liabilitiesData={data.liabilities} />
          </Card>
        </div>
        <Button
          onClick={handleClick}
          value="Перейти к формированию документов"
          color="primary"
        />
      </div>
    </div>
  );
};

export default RequestDecisionPage;
