import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Tabs, {
  IItem,
} from '../../../../../lib/avrora-ui-kit/Tabs/Tabs';
import { selectUniversalRequest } from '../../../../store/selectors';
import * as styles from './styles.css';
import { getUniversalRequest } from '../../../../store/modules/universal-request/actions';
import Button from '../../../../ui/Button';
import Input from '../../../../ui/Input';
import Datalist from '../../../../ui/Datalist';
import Checkbox from '../../../../ui/Checkbox';
import InputRange from '../../../../ui/input-range';

const IndexPage: React.FC = () => {
  const dispatch = useDispatch();
  const universalRequest = useSelector(selectUniversalRequest);
  const history = useHistory();
  const testList: IItem[] = [
    { id: 'firstTab', label: 'Текущий паспорт', isActive: false },
    {
      id: 'secondTab',
      label: 'Данные предыдущего паспорта',
      isActive: true,
    },
  ];

  const [list, setList] = useState(testList);

  useEffect(() => {
    dispatch(getUniversalRequest());
  }, []);

  return (
    <div>
      <h1>Универсальная заявка!</h1>
      <div className={styles.content}>
        <h2>Запрос клиента!</h2>
        <div className={styles.grid}>
          <div>
            <InputRange
              id="input-sum"
              min="50000"
              max="5000000"
              value="50000"
              label="Сумма кредита нал. на руки"
              onChange={() => undefined}
              asterisk
            />
          </div>
          <div>
            <InputRange
              id="input-limit"
              min="100"
              max="5000000"
              value="100"
              label="Запрошенный лимит кред. карты"
              onChange={() => undefined}
              asterisk
            />
          </div>
          <div />
          <div />
        </div>

        <div className={styles.grid}>
          <div>
            <Datalist label="Продукт *" value="Кредит наличными" />
          </div>
          <div />
          <div />
          <div />
        </div>
        <h2>Персональные данные</h2>
        <div className={styles.grid}>
          <div>
            <Input
              label="Фамилия"
              value={universalRequest?.firstName}
            />
          </div>
          <div>
            <Input label="Имя" value="Александра" />
          </div>
          <div>
            <Input label="Отчество" value="Николаевна" />
          </div>
          <div />
        </div>

        <div className={styles.grid}>
          <div>
            <Checkbox
              label="Меняла ФИО"
              onSelect={() => undefined}
              size="s"
            />
          </div>

          <div className={styles.grid}>
            <div>
              <Datalist label="Пол" value="Женский" />
            </div>
            <div>
              <Input label="Дата рождения" value="18.03.2019" />
            </div>
            <div />
            <div />
          </div>

          <h2>Паспортные данные</h2>

          {/* <Tabs
            list={list}
            onChange={({ id, label }: IItem) => {
              setList(
                list.map((item) =>
                  item.id === id
                    ? { id, isActive: true, label }
                    : { ...item, isActive: false },
                ),
              );
            }}
          /> */}

          <br />

          <div className={styles.grid}>
            <div>
              <Input label="Серия и номер паспорта" />
            </div>
            <div>
              <Input label="Дата выдачи" />
            </div>
            <div>
              <Input label="Код подразделения" />
            </div>
            <div />
            <div />
          </div>

          <div className={styles.gridFull}>
            <div>
              <Input label="Кем выдан" />
            </div>
            <div>
              <Input label="Место рождени" />
            </div>
            <div />
            <div />
            <div />
          </div>

          <h2>Адресные данные</h2>
          <div className={styles.gridFull}>
            <div>
              <Input label="Адрес постоянной регистрации" />
            </div>
            <div />
            <div />
            <div />
          </div>

          <div className={styles.gridFull}>
            <div>
              <Input label="Адрес временной регистрации" />
            </div>
            <div>
              <Input label="Дата окончаниия врем. регистрации" />
            </div>
            <div />
            <div />
          </div>

          <div className={styles.gridFull}>
            <div>
              <Input label="Адрес временной регистрации" />
            </div>
            <div />
            <div />
            <div />
          </div>

          <h2>Контактные данные</h2>
          <div className={styles.grid}>
            <div>
              <Input
                label="Мобильный телефон"
                value="+7 (926) 106 3345"
              />
            </div>
            <div>
              <Input label="Электронная почта" />
            </div>
            <div>
              <Datalist
                label="Образование"
                value="Укажите образование"
              />
            </div>
            <div />
          </div>

          <h2>Семья</h2>
          <div className={styles.gridFull}>
            <div>
              <Datalist
                label="Семейное положение"
                value="Укажите образование"
              />
            </div>
            <div />
            <div />
            <div />
          </div>

          <h2>Основное место работы</h2>
          <div className={styles.gridFull}>
            <div>
              <Input label="Наименование работодателя" />
            </div>
            <div>
              <Input label="ИНН организации *" />
            </div>
            <div />
            <div />
          </div>

          <div className={styles.gridFull}>
            <div>
              <Input label="Основной доход (сможет подтвердить), руб * " />
            </div>
            <div>
              <Input label="Тип подтверждения дохода *" />
            </div>
            <div />
            <div />
          </div>

          <hr className={styles.hr} />

          <h2>Дополнительное место работы:</h2>
          <span className={styles.add}>Добавить</span>

          <h2>Дополнительный доход:</h2>
          <span className={styles.add}>Добавить</span>

          <div className={styles.buttonBox}>
            <div className={styles.buttonBox}>
              <div className={styles.button}>
                <Button
                  value="Отправить на проверку"
                  onClick={() => {
                    history.push('/request');
                  }}
                />
              </div>

              <div className={styles.button}>
                <Button
                  value="Показать анкету клиенту"
                  color="secondary"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IndexPage;
