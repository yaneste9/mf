import React from 'react';
import { Route, Switch } from 'react-router-dom';
import MainRoutes from './routers/main';
import PageNotFound from './routers/page-not-found';
import LayoutDefault from '../components/layout';

const combineRouters = [...MainRoutes];

const WrappedComponent = (
  Component: React.ReactType,
  Layout: React.ReactType,
): React.ReactNode => (
  <Layout>
    <Component />
  </Layout>
);

const App: React.FC = () => (
  <Switch>
    {combineRouters.map((item, index: number) => (
      <Route
        key={index}
        exact
        path={item.path}
        render={(): React.ReactNode =>
          WrappedComponent(
            item.component,
            item.layout ? item.layout : LayoutDefault,
          )
        }
      />
    ))}
    <Route component={PageNotFound} />
  </Switch>
);

export default App;
