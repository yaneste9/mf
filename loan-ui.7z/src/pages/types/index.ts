import React from 'react';

export type RoutersType = Array<{
  path: string;
  layout?: React.ReactType;
  component: React.ReactType;
}>;
