export const INDEX_PAGE_PATH = '/';
export const REQUEST_PATH = '/request';
export const REQUEST_DECISION_PATH = '/request_decision';
export const SIGNED_AGREEMENT_PATH = '/signed_agreement';
