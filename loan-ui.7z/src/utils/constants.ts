export enum Currency {
  RUB = '\u20BD',
}
