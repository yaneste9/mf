import createNumberMask from 'text-mask-addons/dist/createNumberMask';

// eslint-disable-next-line
export const createCurrencyMask = (maxNum: number, suffix = '') =>
  createNumberMask({
    prefix: '',
    suffix,
    thousandsSeparatorSymbol: ' ',
    integerLimit: maxNum,
  });

// eslint-disable-next-line
export const createPercentageMask = () =>
  createNumberMask({
    prefix: '',
    suffix: ' %',
    thousandsSeparatorSymbol: ' ',
    integerLimit: 3,
  });

// eslint-disable-next-line
export const createPhoneCodeMask = () =>
  createNumberMask({
    prefix: '+7 (',
    suffix: ')',
    thousandsSeparatorSymbol: '',
    integerLimit: 5,
  });

export const clearCurrencyFormat = (value: string): string => {
  return value.replace('\u20BD', '').split(' ').join('');
};
